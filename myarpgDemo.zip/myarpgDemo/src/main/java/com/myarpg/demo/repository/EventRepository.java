package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.myarpg.demo.entities.EventPojo;

public interface EventRepository extends CrudRepository<EventPojo, Long> {

	List<EventPojo> findAll();

	List<EventPojo> findByGroupID(Long groupID);

	EventPojo findByGroupIDAndCategoryAndNumber(Long groupID, String selectedType, Long selectedEventNumber);

	EventPojo findFirstByGroupIDAndCategoryOrderByEventIDDesc(Long groupID, String string);

	EventPojo findFirstByGroupIDAndCategoryAndNumberOrderByEventIDDesc(Long groupID, String string, long number);

	EventPojo findByEventID(Long eventID);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM event_pojo WHERE eventid = :eventid ;", nativeQuery = true)
	public void deleteByEventID(@Param("eventid") Long eventid);

}
