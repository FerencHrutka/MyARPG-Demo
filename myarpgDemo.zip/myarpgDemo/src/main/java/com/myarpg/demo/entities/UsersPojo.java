package com.myarpg.demo.entities;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;

import org.joda.time.DateTime;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class UsersPojo {

	@Id
	@GeneratedValue
	private Long userID;

	@Column(unique = true, nullable = false)
	private String userName;

	@Column(unique = true, nullable = false)
	private String userEmail;

	@Column(nullable = false)
	private String userPassword;
	private String userActivationKey;

	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm:ss")
	private DateTime userJoinedDate;

	@DateTimeFormat(pattern = "yyyy.MM.dd")
	private DateTime userBirthday;

	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm:ss")
	private DateTime userLastActivity;
	private Boolean userEnabled;

	private String userPictureUrl;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "usersAddressPojo_usersAddressID")
	private UsersAddressPojo usersAddressPojo;

	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "users_roles", joinColumns = { @JoinColumn(name = "UsersPojo_userID") }, inverseJoinColumns = {
			@JoinColumn(name = "role_roleID") })
	private Set<Role> role = new HashSet<Role>();

	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "users_access", joinColumns = { @JoinColumn(name = "UsersPojo_userID") }, inverseJoinColumns = {
			@JoinColumn(name = "AccessPojo_accessID") })
	private List<AccessPojo> accessPojoList = new ArrayList<AccessPojo>();

	@ManyToMany
	@JoinTable(name = "users_access_lobby", joinColumns = { @JoinColumn(name = "UsersPojo_userID") }, inverseJoinColumns = {
			@JoinColumn(name = "AccessPojo_accessID") })
	private List<AccessPojo> accessPojoLobbyList = new ArrayList<AccessPojo>();

	@ManyToMany
	@JoinTable(name = "users_access_invite", joinColumns = { @JoinColumn(name = "UsersPojo_userID") }, inverseJoinColumns = {
			@JoinColumn(name = "AccessPojo_accessID") })
	private List<AccessPojo> accessPojoInviteList = new ArrayList<AccessPojo>();

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "userID", nullable = true)
	private List<BankPojo> BankPojo;

	@OneToMany(cascade = CascadeType.ALL)
	@OrderBy("upgradeUserID ASC")
	@JoinColumn(name = "userID", referencedColumnName = "userID")
	private List<UpgradeUserPojo> upgradeUserPojo;

	@OneToMany(cascade = CascadeType.ALL)
	@OrderBy("messageID DESC")
	@JoinColumn(name = "senderUsersPojo", referencedColumnName = "userID")
	private List<MessagePojo> senderMessagePojo;

	@OneToMany(cascade = CascadeType.ALL)
	@OrderBy("messageID DESC")
	@JoinColumn(name = "reciverUsersPojo", referencedColumnName = "userID")
	private List<MessagePojo> reciverMessagePojo;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "userID", nullable = true)
	@OrderBy("logID DESC")
	private List<LogPojo> logPojo;

	private Integer firstDayOfWeek;

	@OneToOne(cascade = CascadeType.ALL)
	private UserInformationPojo userInformationPojo;

	public Set<Role> getRole() {
		return role;
	}

	public void setRole(Set<Role> role) {
		this.role = role;
	}

	public UsersPojo() {
	}

	public UsersAddressPojo getUsersAddressPojo() {
		return usersAddressPojo;
	}

	public void setUsersAddressPojo(UsersAddressPojo usersAddressPojo) {
		this.usersAddressPojo = usersAddressPojo;
	}

	public DateTime getUserLastActivity() {
		return userLastActivity;
	}

	public void setUserLastActivity(DateTime userLastActivity) {
		this.userLastActivity = userLastActivity;
	}

	public Long getUserID() {
		return userID;
	}

	public void setUserID(Long userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public String getUserPictureUrl() {
		return userPictureUrl;
	}

	public void setUserPictureUrl(String userPictureUrl) {
		this.userPictureUrl = userPictureUrl;
	}

	public Boolean getUserEnabled() {
		return userEnabled;
	}

	public void setUserEnabled(Boolean userEnabled) {
		this.userEnabled = userEnabled;
	}

	public String getUserActivationKey() {
		return userActivationKey;
	}

	public void setUserActivationKey(String userActivationKey) {
		this.userActivationKey = userActivationKey;
	}

	public void addRoles(String roleName) {
		if (this.role == null || this.role.isEmpty()) {
			this.role = new HashSet<>();
		}
		this.role.add(new Role(roleName));
	}

	public List<BankPojo> getBankPojo() {
		return BankPojo;
	}

	public void setBankPojo(List<BankPojo> bankPojo) {
		BankPojo = bankPojo;
	}

	public Integer getFirstDayOfWeek() {
		return firstDayOfWeek;
	}

	public void setFirstDayOfWeek(Integer firstDayOfWeek) {
		this.firstDayOfWeek = firstDayOfWeek;
	}

	public List<AccessPojo> getAccessPojoList() {
		return accessPojoList;
	}

	public void setAccessPojoList(List<AccessPojo> accessPojoList) {
		this.accessPojoList = accessPojoList;
	}

	public List<AccessPojo> getAccessPojoLobbyList() {
		return accessPojoLobbyList;
	}

	public void setAccessPojoLobbyList(List<AccessPojo> accessPojoLobbyList) {
		this.accessPojoLobbyList = accessPojoLobbyList;
	}

	public List<UpgradeUserPojo> getUpgradeUserPojo() {
		return upgradeUserPojo;
	}

	public void setUpgradeUserPojo(List<UpgradeUserPojo> upgradeUserPojo) {
		this.upgradeUserPojo = upgradeUserPojo;
	}

	public List<MessagePojo> getSenderMessagePojo() {
		return senderMessagePojo;
	}

	public void setSenderMessagePojo(List<MessagePojo> senderMessagePojo) {
		this.senderMessagePojo = senderMessagePojo;
	}

	public List<MessagePojo> getReciverMessagePojo() {
		return reciverMessagePojo;
	}

	public void setReciverMessagePojo(List<MessagePojo> reciverMessagePojo) {
		this.reciverMessagePojo = reciverMessagePojo;
	}

	public List<LogPojo> getLogPojo() {
		return logPojo;
	}

	public void setLogPojo(List<LogPojo> logPojo) {
		this.logPojo = logPojo;
	}

	public List<AccessPojo> getAccessPojoInviteList() {
		return accessPojoInviteList;
	}

	public void setAccessPojoInviteList(List<AccessPojo> accessPojoInviteList) {
		this.accessPojoInviteList = accessPojoInviteList;
	}

	public UserInformationPojo getUserInformationPojo() {
		return userInformationPojo;
	}

	public void setUserInformationPojo(UserInformationPojo userInformationPojo) {
		this.userInformationPojo = userInformationPojo;
	}

	public DateTime getUserJoinedDate() {
		return userJoinedDate;
	}

	public void setUserJoinedDate(DateTime userJoinedDate) {
		this.userJoinedDate = userJoinedDate;
	}

	public DateTime getUserBirthday() {
		return userBirthday;
	}

	public void setUserBirthday(DateTime userBirthday) {
		this.userBirthday = userBirthday;
	}

}
