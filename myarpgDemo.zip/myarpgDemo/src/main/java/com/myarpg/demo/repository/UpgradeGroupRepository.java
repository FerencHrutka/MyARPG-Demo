package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.UpgradeGroupPojo;

public interface UpgradeGroupRepository extends CrudRepository<UpgradeGroupPojo, Long> {

	List<UpgradeGroupPojo> findAll();

	UpgradeGroupPojo findByGroupIDAndName(Long groupID, String upgradeName);

}
