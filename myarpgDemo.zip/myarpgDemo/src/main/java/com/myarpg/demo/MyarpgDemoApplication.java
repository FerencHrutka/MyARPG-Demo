package com.myarpg.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestTemplate;


@EnableConfigurationProperties
@PropertySources({
    @PropertySource(value = "file:${appConf}", ignoreResourceNotFound = true)
})  
@SpringBootApplication
@ComponentScan({"com.example","controller"})
public class MyarpgDemoApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(MyarpgDemoApplication.class, args);
	}
	
	@Bean
	public RestTemplate restTamplate() {
		return new RestTemplate();
	}
	
	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
	  return application.sources(MyarpgDemoApplication.class);
    }      

}


@Configuration
@EnableScheduling
@ConditionalOnProperty(name = "scheduling.enabled", matchIfMissing = true)
class SchedulingConfiguration{
	
}