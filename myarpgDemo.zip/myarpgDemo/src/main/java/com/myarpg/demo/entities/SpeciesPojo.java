package com.myarpg.demo.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;

@Entity
public class SpeciesPojo {

	@Id
	@GeneratedValue
	private Long speciesID;
	private Long groupID;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "speciesID", nullable = true)
	@OrderBy("number desc")
	private List<CharactersPojo> charactersPojo;
	private Long subSpeciesID;
	private String name;

	@Column(length = 4000)
	private String description;
	private String url;

	@OneToOne
	private ImgStoragePojo imgStoragePojo;

	public SpeciesPojo() {
	}

	public Long getSpeciesID() {
		return speciesID;
	}

	public void setSpeciesID(Long speciesID) {
		this.speciesID = speciesID;
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	public List<CharactersPojo> getCharactersPojo() {
		return charactersPojo;
	}

	public void setCharactersPojo(List<CharactersPojo> charactersPojo) {
		this.charactersPojo = charactersPojo;
	}

	public Long getSubSpeciesID() {
		return subSpeciesID;
	}

	public void setSubSpeciesID(Long subSpeciesID) {
		this.subSpeciesID = subSpeciesID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public ImgStoragePojo getImgStoragePojo() {
		return imgStoragePojo;
	}

	public void setImgStoragePojo(ImgStoragePojo imgStoragePojo) {
		this.imgStoragePojo = imgStoragePojo;
	}

}
