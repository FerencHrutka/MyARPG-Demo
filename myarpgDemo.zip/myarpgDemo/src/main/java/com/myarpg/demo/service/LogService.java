package com.myarpg.demo.service;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myarpg.demo.entities.EventPojo;
import com.myarpg.demo.entities.GroupsPojo;
import com.myarpg.demo.entities.LogPojo;
import com.myarpg.demo.entities.UsersPojo;
import com.myarpg.demo.repository.LogRepository;

@Service
public class LogService {

	LogRepository logRepository;

	@Autowired
	public void setLogRepository(LogRepository logRepository) {
		this.logRepository = logRepository;
	}

	public void logNewEvent(UsersPojo loggedUser, GroupsPojo selectedGroup, EventPojo thymeleafEventPojo) {
		LogPojo newLogPojo = new LogPojo();
		newLogPojo.setUserID(loggedUser.getUserID());
		newLogPojo.setGroupID(selectedGroup.getGroupID());
		newLogPojo.setTimestamp(DateTime.now());
		newLogPojo.setType("event");
		newLogPojo.setLog("'" + loggedUser.getUserName() + "' user created a new event: '" + thymeleafEventPojo.getTitle() + "' in '"
				+ selectedGroup.getName() + "' group.");
		logRepository.save(newLogPojo);
	}

	public void logEditEvent(UsersPojo loggedUser, GroupsPojo selectedGroup, EventPojo thymeleafEventPojo) {
		LogPojo newLogPojo = new LogPojo();
		newLogPojo.setUserID(loggedUser.getUserID());
		newLogPojo.setGroupID(selectedGroup.getGroupID());
		newLogPojo.setTimestamp(DateTime.now());
		newLogPojo.setType("event");
		newLogPojo.setLog("'" + loggedUser.getUserName() + "' user edit this event: '" + thymeleafEventPojo.getTitle() + "' in '"
				+ selectedGroup.getName() + "' group.");
		logRepository.save(newLogPojo);
	}
}
