package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.myarpg.demo.entities.CharacterPropertiesPojo;

public interface CharacterPropertiesRepository extends CrudRepository<CharacterPropertiesPojo, Long> {

	List<CharacterPropertiesPojo> findAll();

	List<CharacterPropertiesPojo> findByCharacterID(Long characterID);

	CharacterPropertiesPojo findByCharacterIDAndPosition(Long characterID, Integer propertiesPosition);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM character_properties_pojo WHERE character_propertiesid = :characterPropertiesID ;", nativeQuery = true)
	public void deleteByCharacterPropertiesID(@Param("characterPropertiesID") Long characterPropertiesID);
	
}
