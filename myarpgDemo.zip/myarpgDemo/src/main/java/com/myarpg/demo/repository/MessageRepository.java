package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.MessagePojo;

public interface MessageRepository extends CrudRepository<MessagePojo, Long> {

	List<MessagePojo> findAll();

	MessagePojo findBymessageID(Long messageID);
	
}
