package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.myarpg.demo.entities.ItemsPojo;

public interface ItemsRepository extends CrudRepository<ItemsPojo, Long> {

	List<ItemsPojo> findAll();

	List<ItemsPojo> findByGroupID(Long groupID);

	Integer countByItemCategoriesID(Long itemCategoriesID);

	List<ItemsPojo> findByItemCategoriesID(Long itemCategoriesID, Pageable pageable);

	ItemsPojo findFirstByItemCategoriesIDOrderByItemIDDesc(Long itemCategoriesID);

	ItemsPojo findByNumberAndItemCategoriesID(Long castSelectedItemsNumberToLong, Long itemCategoriesID);

	ItemsPojo findByItemID(Long itemID);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM items_pojo WHERE itemid = :itemID ;", nativeQuery = true)
	public void deleteByItemID(@Param("itemID") Long itemID);

}
