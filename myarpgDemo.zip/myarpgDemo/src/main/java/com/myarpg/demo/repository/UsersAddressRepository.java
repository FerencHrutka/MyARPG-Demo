package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.UsersAddressPojo;

public interface UsersAddressRepository extends CrudRepository<UsersAddressPojo, Long> {

	List<UsersAddressPojo> findAll();
	
}
