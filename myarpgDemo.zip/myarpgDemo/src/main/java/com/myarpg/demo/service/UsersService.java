package com.myarpg.demo.service;

import java.util.List;
import java.util.Random;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.myarpg.demo.entities.Role;
import com.myarpg.demo.entities.UserInformationPojo;
import com.myarpg.demo.entities.UsersPojo;
import com.myarpg.demo.repository.RoleRepository;
import com.myarpg.demo.repository.UsersRepository;

@Service
public class UsersService implements UserDetailsService {

	private EmailService emailService;

	@Autowired
	public void setJavaMailSender(EmailService emailService) {
		this.emailService = emailService;
	}

	UsersRepository userRepository;
	RoleRepository roleRepository;

	@Autowired
	public void setUsersRepo(UsersRepository userRepository, RoleRepository roleRepository) {
		this.roleRepository = roleRepository;
		this.userRepository = userRepository;
	}

	public UsersPojo findByUserEmail(String email) {
		return userRepository.findByuserEmailIgnoreCase(email);
	}

	@Override
	public UserDetails loadUserByUsername(String getEmailAddressFromLoginPage) throws UsernameNotFoundException {
		UsersPojo usersSearchByEmail = findByUserEmail(getEmailAddressFromLoginPage);

		if (usersSearchByEmail == null) {

			throw new UsernameNotFoundException(getEmailAddressFromLoginPage);
		}

		saveLastLogin(usersSearchByEmail);
		return new UsersLogin(usersSearchByEmail);
	}

	public void registerUser(UsersPojo filledUserByThymeleaf) {
		filledUserByThymeleaf.setUserEnabled(false);
		filledUserByThymeleaf.setUserActivationKey(generateActivationKey());
		Role userRole = roleRepository.findByRole("ROLE_USER");
		if (userRole != null) {
			filledUserByThymeleaf.getRole().add(userRole);
		} else {
			filledUserByThymeleaf.addRoles("ROLE_USER");
		}

		String encodedPassword = new BCryptPasswordEncoder().encode(filledUserByThymeleaf.getUserPassword());
		filledUserByThymeleaf.setUserPassword(encodedPassword);
		filledUserByThymeleaf.setUserPictureUrl("/img/default/primary_user_avatar/primary_user_avatar.png");
		filledUserByThymeleaf.setUserJoinedDate(DateTime.now());
		filledUserByThymeleaf.setUserBirthday(filledUserByThymeleaf.getUserBirthday());
		filledUserByThymeleaf.setFirstDayOfWeek(0);
		emailService.sendRegistrationMessage(filledUserByThymeleaf.getUserEmail(),
				filledUserByThymeleaf.getUsersAddressPojo().getUserFirstName(), filledUserByThymeleaf.getUserActivationKey());
		userRepository.save(filledUserByThymeleaf);
	}

	public String generateActivationKey() {
		Random random = new Random();
		char[] word = new char[16];
		for (int x = 0; x < word.length; x++) {
			word[x] = (char) ('a' + random.nextInt(26));
		}
		return new String(word);
	}

	public UsersPojo findByUserActivationKey(String key) {
		return userRepository.findByuserActivationKey(key);
	}

	public void activationUser(UsersPojo userToActivation) {
		userToActivation.setUserEnabled(true);
		userToActivation.setUserActivationKey("");
		userRepository.save(userToActivation);
	}

	public UsersPojo loggedUserPojo() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		UsersPojo loggedUser = userRepository.findByuserEmailIgnoreCase(authentication.getName());
		return loggedUser;
	}

	public void saveLastLogin(UsersPojo loggedUser) {
		loggedUser.setUserLastActivity(DateTime.now());
		userRepository.save(loggedUser);
	}

	public UsersPojo findByuserNameIgnoreCase(String userName) {
		UsersPojo selectedUsersPojo = null;
		try {
			selectedUsersPojo = userRepository.findByuserNameIgnoreCase(userName);
		} catch (Exception e) {
		}

		return selectedUsersPojo;
	}

	public void saveThisUser(UsersPojo loggedUser) {
		userRepository.save(loggedUser);
	}

	public UsersPojo getRobotUserPojo() {
		return userRepository.findByuserNameIgnoreCase("robot");
	}

	public List<UsersPojo> findByUserEnabledTrueOrderByUserNameAsc() {
		return userRepository.findByUserEnabledTrueOrderByUserNameAsc();
	}

	public void editAboutMe(UsersPojo loggedUser, String editAboutMeSummernote) {
		if (loggedUser.getUserInformationPojo() != null) {
			loggedUser.getUserInformationPojo().setAboutMe(editAboutMeSummernote);
			userRepository.save(loggedUser);
		} else {
			UserInformationPojo userInformationPojo = new UserInformationPojo();
			userInformationPojo.setAboutMe(editAboutMeSummernote);
			userInformationPojo.setUsersPojo(loggedUser);
			loggedUser.setUserInformationPojo(userInformationPojo);
			userRepository.save(loggedUser);
		}
	}

}
