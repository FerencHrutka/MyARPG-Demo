package com.myarpg.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.myarpg.demo.entities.CommentPojo;
import com.myarpg.demo.entities.GroupsHomePojo;
import com.myarpg.demo.entities.GroupsPojo;
import com.myarpg.demo.entities.UsersPojo;
import com.myarpg.demo.repository.CommentRepository;
import com.myarpg.demo.repository.GroupsHomeRepository;
import com.myarpg.demo.repository.GroupsRepository;

@Service
public class GroupService {
	GroupsRepository groupsRepository;

	@Autowired
	public void setGroupsRepository(GroupsRepository groupsRepository) {
		this.groupsRepository = groupsRepository;
	}

	GroupsHomeRepository groupsHomeRepository;

	@Autowired
	public void setGroupsHomeRepository(GroupsHomeRepository groupsHomeRepository) {
		this.groupsHomeRepository = groupsHomeRepository;
	}

	CommentRepository commentRepository;

	@Autowired
	public void setCommentRepository(CommentRepository commentRepository) {
		this.commentRepository = commentRepository;
	}

	public GroupsPojo findByUrlIgnoreCase(String groupUrlName) {
		return groupsRepository.findByUrl(groupUrlName);
	}

	public GroupsPojo findBygroupID(long groupID) {
		return groupsRepository.findBygroupID(groupID);
	}

	public void moveDownHomeElement(GroupsPojo selectedGroup, GroupsHomePojo thymeleafGroupsHomePojo) {
		boolean doThisOnlyOnce = false;
		for (int i = 0; i < selectedGroup.getGroupsHomePojo().size(); i++) {
			if (selectedGroup.getGroupsHomePojo().get(i).getPosition() == thymeleafGroupsHomePojo.getPosition() && !doThisOnlyOnce
					&& thymeleafGroupsHomePojo.getPosition() > 1) {
				selectedGroup.getGroupsHomePojo().get(i).setPosition(thymeleafGroupsHomePojo.getPosition() - 1);
				selectedGroup.getGroupsHomePojo().get(i + 1).setPosition(thymeleafGroupsHomePojo.getPosition());
				groupsHomeRepository.saveAll(selectedGroup.getGroupsHomePojo());
				doThisOnlyOnce = true;
			}
		}
	}

	public void moveUpHomeElement(GroupsPojo selectedGroup, GroupsHomePojo thymeleafGroupsHomePojo) {
		boolean doThisOnlyOnce = false;
		for (int i = 0; i < selectedGroup.getGroupsHomePojo().size(); i++) {
			if (selectedGroup.getGroupsHomePojo().get(i).getPosition() == thymeleafGroupsHomePojo.getPosition() && !doThisOnlyOnce
					&& thymeleafGroupsHomePojo.getPosition() < selectedGroup.getGroupsHomePojo().size()) {
				selectedGroup.getGroupsHomePojo().get(i).setPosition(thymeleafGroupsHomePojo.getPosition() + 1);
				selectedGroup.getGroupsHomePojo().get(i - 1).setPosition(thymeleafGroupsHomePojo.getPosition());
				groupsHomeRepository.saveAll(selectedGroup.getGroupsHomePojo());
				doThisOnlyOnce = true;
			}
		}
	}

	public GroupsPojo getGroupsPojoBySelectedGroupUrl(String selectedGroupUrl) {
		GroupsPojo selectedGroup = null;
		try {
			selectedGroup = groupsRepository.findByUrl("/group/" + selectedGroupUrl);
		} catch (Exception e) {
		}
		if (selectedGroup != null) {
			return selectedGroup;
		}
		return null;
	}

	public CommentPojo findByCommentID(Long commentID) {
		CommentPojo selectedCommentPojo = null;
		try {
			selectedCommentPojo = commentRepository.findByCommentID(commentID);
		} catch (Exception e) {
		}

		return selectedCommentPojo;
	}

	public String hideComment(GroupsPojo selectedGroup, UsersPojo loggedUser, CommentPojo thymeleafCommentPojo) {
		CommentPojo selectedCommentPojo = findByCommentID(thymeleafCommentPojo.getReply());
		if (selectedCommentPojo == null) {
			return null;
		}

		selectedCommentPojo.setHide(true);
		commentRepository.save(selectedCommentPojo);
		return null;
	}

	public Long countGroups() {
		return groupsRepository.count();
	}

	public List<GroupsPojo> findAllWithPageRequest(PageRequest pageRequest) {
		return groupsRepository.findByGroupIDNot(0L, pageRequest);
	}

	public Integer countByNameIsContainingIgnoreCase(String name) {
		return groupsRepository.countByNameIsContainingIgnoreCase(name);
	}

	public List<GroupsPojo> findByNameIsContainingIgnoreCaseWithPageRequest(String name, PageRequest pageRequest) {
		return groupsRepository.findByNameIsContainingIgnoreCase(name, pageRequest);
	}

}
