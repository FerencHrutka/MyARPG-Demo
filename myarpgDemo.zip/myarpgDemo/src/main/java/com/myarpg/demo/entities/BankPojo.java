package com.myarpg.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class BankPojo {

	@GeneratedValue
	@Id
	private Long bankID;
	private Long groupID;
	private Long userID;
	private Long quantity;
	private boolean changed;
	private boolean newBankItem;
	private Long changedQuantity;

	@OneToOne(cascade = CascadeType.ALL)
	private ItemsPojo itemsPojo;

	public void setCloneBankPojo(BankPojo bankPojo) {
		this.bankID = bankPojo.bankID;
		this.groupID = bankPojo.groupID;
		this.userID = bankPojo.userID;
		this.quantity = bankPojo.quantity;
		this.changed = bankPojo.changed;
		this.newBankItem = bankPojo.newBankItem;
		this.changedQuantity = bankPojo.changedQuantity;
		this.itemsPojo = bankPojo.itemsPojo;
	}

	public BankPojo() {
	}

	public Long getBankID() {
		return bankID;
	}

	public void setBankID(Long bankID) {
		this.bankID = bankID;
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	public Long getQuantity() {
		return quantity;
	}

	public void setQuantity(Long quantity) {
		this.quantity = quantity;
	}

	public Long getUserID() {
		return userID;
	}

	public void setUserID(Long userID) {
		this.userID = userID;
	}

	public ItemsPojo getItemsPojo() {
		return itemsPojo;
	}

	public void setItemsPojo(ItemsPojo itemsPojo) {
		this.itemsPojo = itemsPojo;
	}

	public boolean isChanged() {
		return changed;
	}

	public void setChanged(boolean changed) {
		this.changed = changed;
	}

	public Long getChangedQuantity() {
		return changedQuantity;
	}

	public void setChangedQuantity(Long changedQuantity) {
		this.changedQuantity = changedQuantity;
	}

	public boolean isNewBankItem() {
		return newBankItem;
	}

	public void setNewBankItem(boolean newBankItem) {
		this.newBankItem = newBankItem;
	}

}
