package com.myarpg.demo.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.http.HttpMethod;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.myarpg.demo.entities.AccessPojo;
import com.myarpg.demo.entities.BankPojo;
import com.myarpg.demo.entities.CommentPojo;
import com.myarpg.demo.entities.EventParticipantPojo;
import com.myarpg.demo.entities.EventPojo;
import com.myarpg.demo.entities.GroupsHomePojo;
import com.myarpg.demo.entities.GroupsNewsPojo;
import com.myarpg.demo.entities.GroupsPojo;
import com.myarpg.demo.entities.ImgStoragePojo;
import com.myarpg.demo.entities.MessagePojo;
import com.myarpg.demo.entities.PaginationPojo;
import com.myarpg.demo.entities.ReCaptchaResponse;
import com.myarpg.demo.entities.UpgradePojo;
import com.myarpg.demo.entities.UsersPojo;
import com.myarpg.demo.entities.WarningPojo;
import com.myarpg.demo.paypal.Order;
import com.myarpg.demo.paypal.PaypalService;
import com.myarpg.demo.service.AccessService;
import com.myarpg.demo.service.BankService;
import com.myarpg.demo.service.CensorService;
import com.myarpg.demo.service.CharactersService;
import com.myarpg.demo.service.EventService;
import com.myarpg.demo.service.GroupService;
import com.myarpg.demo.service.ItemsService;
import com.myarpg.demo.service.LogService;
import com.myarpg.demo.service.MessageService;
import com.myarpg.demo.service.SpeciesService;
import com.myarpg.demo.service.UpgradeService;
import com.myarpg.demo.service.UsersService;
import com.myarpg.demo.service.UtilsService;
import com.paypal.api.payments.Links;
import com.paypal.api.payments.Payment;
import com.paypal.base.rest.PayPalRESTException;

@Controller
public class HomeController {

	@Value("${google.reCAPTCHA.key}")
	private String GOOGLE_RECAPTCHA_KEY;

	private UsersService userService;

	@Autowired
	public void setuService(UsersService uService) {
		this.userService = uService;
	}

	private MessageService messageService;

	@Autowired
	public void setMessageService(MessageService messageService) {
		this.messageService = messageService;
	}

	UtilsService utilsService;

	@Autowired
	public void setUtilsService(UtilsService utilsService) {
		this.utilsService = utilsService;
	}

	GroupService groupService;

	@Autowired
	public void setGroupsService(GroupService groupService) {
		this.groupService = groupService;
	}

	SpeciesService speciesService;

	@Autowired
	public void setSpeciesService(SpeciesService speciesService) {
		this.speciesService = speciesService;
	}

	BankService bankService;

	@Autowired
	public void setBankService(BankService bankService) {
		this.bankService = bankService;
	}

	ItemsService itemsService;

	@Autowired
	public void setItemsService(ItemsService itemsService) {
		this.itemsService = itemsService;
	}

	EventService eventService;

	@Autowired
	public void setEventService(EventService eventService) {
		this.eventService = eventService;
	}

	PaypalService paypalService;

	@Autowired
	public void setPaypalService(PaypalService paypalService) {
		this.paypalService = paypalService;
	}

	UpgradeService upgradeService;

	@Autowired
	public void setUpgradeService(UpgradeService upgradeService) {
		this.upgradeService = upgradeService;
	}

	LogService logService;

	@Autowired
	public void setLogService(LogService logService) {
		this.logService = logService;
	}

	CensorService censorService;

	@Autowired
	public void setCensorService(CensorService censorService) {
		this.censorService = censorService;
	}

	AccessService accessService;

	@Autowired
	public void setAccessService(AccessService accessService) {
		this.accessService = accessService;
	}

	CharactersService charactersService;

	@Autowired
	public void setCharactersService(CharactersService charactersService) {
		this.charactersService = charactersService;
	}

//########################################################################################################################################################################################
// __Homepage handlers
//########################################################################################################################################################################################
	@RequestMapping("/")
	public String homepage(Model model) {

		// Preparing
		setUserEnvironment(model);

		// Business logic
		List<ImgStoragePojo> mostViewedImages = utilsService.findFirst20ByOrderByNumberOfViewsDesc();
		model.addAttribute("mostViewedImages", mostViewedImages);

		List<ImgStoragePojo> mostCommentedImages = utilsService.findFirst20ByOrderByNumberOfCommentsDesc();
		model.addAttribute("mostCommentedImages", mostCommentedImages);

		List<ImgStoragePojo> newEventsImages = utilsService.findFirst20ByTopicTypeOrderByImgStorageIDDesc("event");
		model.addAttribute("newEventsImages", newEventsImages);

		List<ImgStoragePojo> newSpeciesImages = utilsService.findFirst20ByTopicTypeOrderByImgStorageIDDesc("species");
		model.addAttribute("newSpeciesImages", newSpeciesImages);

		List<ImgStoragePojo> newCharactersImages = utilsService.findFirst20ByTopicTypeOrderByImgStorageIDDesc("character");
		model.addAttribute("newCharactersImages", newCharactersImages);

		List<ImgStoragePojo> newItemsImages = utilsService.findFirst20ByTopicTypeOrderByImgStorageIDDesc("items");
		model.addAttribute("newItemsImages", newItemsImages);

		return "home";
	}

	@RequestMapping("/show/views")
	public String showViews(Model model, PaginationPojo paginationPojo) throws Exception {

		// Preparing
		setUserEnvironment(model);
		setDefaultPaginationParameters(paginationPojo);

		// Business logic
		Integer countByTopicType = utilsService.countImgStoragePojo();

		paginationPojo.setNumbersOfPages((int) Math.ceil(((double) countByTopicType) / ((double) paginationPojo.getPageSize())));
		model.addAttribute("paginationPojo", paginationPojo);

		List<ImgStoragePojo> imgStoragePojoViewsList = utilsService.findByOrderByNumberOfViewsDesc(
				PageRequest.of(paginationPojo.getPageNumber(), paginationPojo.getPageSize(), Direction.DESC, "imgStorageID"));
		model.addAttribute("imgStoragePojoViewsList", imgStoragePojoViewsList);

		// Breadcrumbs
		List<String> breadcrumbNameList = new ArrayList<String>();
		List<String> breadcrumbUrlList = new ArrayList<String>();
		breadcrumbNameList.add("Most viewed images");
		breadcrumbUrlList.add("/show/views");
		setBreadcrumbs(breadcrumbNameList, breadcrumbUrlList, model);

		return "show/views";
	}

	private void setDefaultPaginationParameters(PaginationPojo paginationPojo) {
		if (paginationPojo.getPageSize() == null) {
			paginationPojo.setPageSize(40);
		}
		if (paginationPojo.getPageNumber() == null) {
			paginationPojo.setPageNumber(0);
		}
	}

	@RequestMapping("/show/comments")
	public String showComments(Model model, PaginationPojo paginationPojo) {

		// Preparing
		setUserEnvironment(model);
		setDefaultPaginationParameters(paginationPojo);

		// Business logic
		Integer countByTopicType = utilsService.countImgStoragePojo();

		paginationPojo.setNumbersOfPages((int) Math.ceil(((double) countByTopicType) / ((double) paginationPojo.getPageSize())));
		model.addAttribute("paginationPojo", paginationPojo);

		List<ImgStoragePojo> imgStoragePojoCommentsList = utilsService.findByOrderByNumberOfCommentsDesc(
				PageRequest.of(paginationPojo.getPageNumber(), paginationPojo.getPageSize(), Direction.DESC, "imgStorageID"));
		model.addAttribute("imgStoragePojoCommentsList", imgStoragePojoCommentsList);

		// Breadcrumbs
		List<String> breadcrumbNameList = new ArrayList<String>();
		List<String> breadcrumbUrlList = new ArrayList<String>();
		breadcrumbNameList.add("Most commented images");
		breadcrumbUrlList.add("/show/comments");
		setBreadcrumbs(breadcrumbNameList, breadcrumbUrlList, model);

		return "show/comments";
	}

	@RequestMapping("/show/events")
	public String showEvents(Model model, PaginationPojo paginationPojo) {

		// Preparing
		setUserEnvironment(model);
		setDefaultPaginationParameters(paginationPojo);

		// Business logic
		Integer countByTopicType = utilsService.countByTopicType("event");

		paginationPojo.setNumbersOfPages((int) Math.ceil(((double) countByTopicType) / ((double) paginationPojo.getPageSize())));
		model.addAttribute("paginationPojo", paginationPojo);

		List<ImgStoragePojo> imgStoragePojoEventsList = utilsService.findByTopicTypeOrderByImgStorageIDDesc("event",
				PageRequest.of(paginationPojo.getPageNumber(), paginationPojo.getPageSize(), Direction.DESC, "imgStorageID"));
		model.addAttribute("imgStoragePojoEventsList", imgStoragePojoEventsList);

		// Breadcrumbs
		List<String> breadcrumbNameList = new ArrayList<String>();
		List<String> breadcrumbUrlList = new ArrayList<String>();
		breadcrumbNameList.add("New events");
		breadcrumbUrlList.add("/show/events");
		setBreadcrumbs(breadcrumbNameList, breadcrumbUrlList, model);

		return "show/events";
	}

	@GetMapping("/logout")
	public String getLogoutPage(HttpServletRequest request, HttpServletResponse response) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null) {
			new SecurityContextLogoutHandler().logout(request, response, authentication);
		}

		// Remember-me Cookie delete:
		Cookie cookie = new Cookie("remember-me", null);
		cookie.setPath("/");
		cookie.setHttpOnly(true);
		cookie.setMaxAge(0);
		response.addCookie(cookie);

		return "redirect:/?logout";
	}

//########################################################################################################################################################################################
// __Registration handlers
//########################################################################################################################################################################################	
	@RequestMapping("/registration")
	public String registration(Model model) {
		model.addAttribute("emptyUser", new UsersPojo());
		return "registration";
	}

	@Autowired
	RestTemplate resTemplate;

	@PostMapping("/reg")
	public String reg(@ModelAttribute UsersPojo userForActivation, @RequestParam(name = "g-recaptcha-response") String capthaResponse) {

		// Business logic
		String url = "https://www.google.com/recaptcha/api/siteverify";
		String params = "?secret=" + GOOGLE_RECAPTCHA_KEY + "&response=" + capthaResponse;
		ReCaptchaResponse reCaptchaResponse = resTemplate.exchange(url + params, HttpMethod.POST, null, ReCaptchaResponse.class).getBody();

		if (reCaptchaResponse.isSuccess()) {

			UsersPojo usersCheckByEmail = null;
			usersCheckByEmail = userService.findByUserEmail(userForActivation.getUserEmail());
			if (usersCheckByEmail != null) {
				return "redirect:registration?errorEmailUsed";
			}

			UsersPojo usersCheckByName = null;
			usersCheckByName = userService.findByuserNameIgnoreCase(userForActivation.getUserName());
			if (usersCheckByName != null) {
				return "redirect:registration?errorUserNameUsed";
			}

			Boolean userNameCensorCheck = false;
			userNameCensorCheck = utilsService.userNameCensorCheck(userForActivation.getUserName());
			if (userNameCensorCheck == false) {
				return "redirect:registration?errorUserNameCensorCheck";
			}

			userService.registerUser(userForActivation);
			return "redirect:login?registrationSucces";
		}
		return "redirect:registration?errorCaptcha";
	}

	@RequestMapping("/activation/{urlKey}")
	public String userActivation(@PathVariable(value = "urlKey") String activationKey) throws Exception {

		// Business logic
		UsersPojo userWhoWannaActivation = null;
		try {
			userWhoWannaActivation = userService.findByUserActivationKey(activationKey);
		} catch (Exception e) {
		}

		if (userWhoWannaActivation == null) {
			return "redirect:/login?noresult";
		}
		userService.activationUser(userWhoWannaActivation);
		return "redirect:/login?succes";

	}

//########################################################################################################################################################################################
// __Groups handlers
//########################################################################################################################################################################################	
	@RequestMapping("/groups")
	public String groups(Model model, PaginationPojo paginationPojo) {

		// Preparing
		setUserEnvironment(model);
		setDefaultPaginationParameters(paginationPojo);

		// Business logic
		Integer countForPaginationPage = groupService.countGroups().intValue();

		paginationPojo.setNumbersOfPages((int) Math.ceil(((double) countForPaginationPage) / ((double) paginationPojo.getPageSize())));

		List<GroupsPojo> groupsPojoList = groupService.findAllWithPageRequest(
				PageRequest.of(paginationPojo.getPageNumber(), paginationPojo.getPageSize(), Direction.ASC, "name"));

		model.addAttribute("paginationPojo", paginationPojo);
		model.addAttribute("emptyGroupsPojo", new GroupsPojo());
		model.addAttribute("groupsPojoList", groupsPojoList);

		// Breadcrumbs
		List<String> breadcrumbNameList = new ArrayList<String>();
		List<String> breadcrumbUrlList = new ArrayList<String>();
		breadcrumbNameList.add("Groups");
		breadcrumbUrlList.add("/groups");
		setBreadcrumbs(breadcrumbNameList, breadcrumbUrlList, model);

		return "groups";
	}

	@RequestMapping("/groupSearch")
	public String groupSearch(@ModelAttribute GroupsPojo thymeleafGroupsPojo, Model model, PaginationPojo paginationPojo) {

		// Preparing
		setUserEnvironment(model);
		setDefaultPaginationParameters(paginationPojo);

		// Business logic
		Integer countForPaginationPage = groupService.countByNameIsContainingIgnoreCase(thymeleafGroupsPojo.getName());

		paginationPojo.setNumbersOfPages((int) Math.ceil(((double) countForPaginationPage) / ((double) paginationPojo.getPageSize())));

		List<GroupsPojo> groupsPojoList = groupService.findByNameIsContainingIgnoreCaseWithPageRequest(thymeleafGroupsPojo.getName(),
				PageRequest.of(paginationPojo.getPageNumber(), paginationPojo.getPageSize(), Direction.ASC, "name"));

		model.addAttribute("paginationPojo", paginationPojo);
		model.addAttribute("groupsPojoList", groupsPojoList);
		model.addAttribute("emptyGroupsPojo", new GroupsPojo());

		// Breadcrumbs
		List<String> breadcrumbNameList = new ArrayList<String>();
		List<String> breadcrumbUrlList = new ArrayList<String>();
		breadcrumbNameList.add("Groups");
		breadcrumbUrlList.add("/groups");
		breadcrumbNameList.add("Searched group(s)");
		breadcrumbUrlList.add("#");
		setBreadcrumbs(breadcrumbNameList, breadcrumbUrlList, model);

		return "groups";
	}

	@RequestMapping("/group/{groupUrlName}")
	public String groupMain(@PathVariable(value = "groupUrlName") String groupUrlName, Model model) throws Exception {

		// Preparing
		GroupsPojo selectedGroup = setGroupEnvironment(model, groupUrlName);

		if (selectedGroup == null) {
			return "redirect:/groups?nothingFoundMatch";
		}

		// Business logic
		List<GroupsNewsPojo> groupsNewsPojoList = selectedGroup.getGroupsNewsPojo();
		model.addAttribute("groupsNewsPojoList", groupsNewsPojoList);

		List<GroupsHomePojo> groupsHomePojoList = selectedGroup.getGroupsHomePojo();
		model.addAttribute("groupsHomePojoList", groupsHomePojoList);

		GroupsHomePojo emptyGroupsHomePojo = new GroupsHomePojo();
		model.addAttribute("emptyGroupsHomePojo", emptyGroupsHomePojo);

		List<ImgStoragePojo> mostViewedImages = utilsService
				.findFirst20ByGroupsPojoGroupIDOrderByNumberOfViewsDesc(selectedGroup.getGroupID());
		model.addAttribute("mostViewedImages", mostViewedImages);

		List<ImgStoragePojo> mostCommentedImages = utilsService
				.findFirst20ByGroupsPojoGroupIDOrderByNumberOfCommentsDesc(selectedGroup.getGroupID());
		model.addAttribute("mostCommentedImages", mostCommentedImages);

		List<ImgStoragePojo> newEventsImages = utilsService
				.findFirst20ByGroupsPojoGroupIDAndTopicTypeOrderByImgStorageIDDesc(selectedGroup.getGroupID(), "event");
		model.addAttribute("newEventsImages", newEventsImages);

		List<ImgStoragePojo> newSpeciesImages = utilsService
				.findFirst20ByGroupsPojoGroupIDAndTopicTypeOrderByImgStorageIDDesc(selectedGroup.getGroupID(), "species");
		model.addAttribute("newSpeciesImages", newSpeciesImages);

		List<ImgStoragePojo> newCharactersImages = utilsService
				.findFirst20ByGroupsPojoGroupIDAndTopicTypeOrderByImgStorageIDDesc(selectedGroup.getGroupID(), "character");
		model.addAttribute("newCharactersImages", newCharactersImages);

		List<ImgStoragePojo> newItemsImages = utilsService
				.findFirst20ByGroupsPojoGroupIDAndTopicTypeOrderByImgStorageIDDesc(selectedGroup.getGroupID(), "items");
		model.addAttribute("newItemsImages", newItemsImages);

		List<ImgStoragePojo> newEventEntriesImages = utilsService
				.findFirst20ByGroupsPojoGroupIDAndTopicTypeOrderByImgStorageIDDesc(selectedGroup.getGroupID(), "Event entry");
		model.addAttribute("newEventEntriesImages", newEventEntriesImages);

		// Breadcrumbs
		List<String> breadcrumbNameList = new ArrayList<String>();
		List<String> breadcrumbUrlList = new ArrayList<String>();
		breadcrumbNameList.add(selectedGroup.getName());
		breadcrumbUrlList.add(selectedGroup.getUrl());
		setBreadcrumbs(breadcrumbNameList, breadcrumbUrlList, model);

		return "groupMain";
	}

	@RequestMapping("/group/{selectedGroupUrl}/moveDownHomeElement")
	public String moveDownHomeElement(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl,
			GroupsHomePojo thymeleafGroupsHomePojo) {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();
		AccessPojo loggedUserAccessPojo = accessService.setLoggedUserAccessPojo(loggedUser, selectedGroup);

		// Business logic
		if (loggedUserAccessPojo.isGroupHomeListEdit()) {
			groupService.moveDownHomeElement(selectedGroup, thymeleafGroupsHomePojo);
		}

		return "redirect:" + selectedGroup.getUrl();
	}

	@RequestMapping("/group/{selectedGroupUrl}/moveUpHomeElement")
	public String moveUpHomeElement(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl,
			GroupsHomePojo thymeleafGroupsHomePojo) {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();
		AccessPojo loggedUserAccessPojo = accessService.setLoggedUserAccessPojo(loggedUser, selectedGroup);

		// Business logic
		if (loggedUserAccessPojo.isGroupHomeListEdit()) {
			groupService.moveUpHomeElement(selectedGroup, thymeleafGroupsHomePojo);
		}

		return "redirect:" + selectedGroup.getUrl();
	}

//########################################################################################################################################################################################
// __Events handlers
//########################################################################################################################################################################################	
	@RequestMapping("/group/{selectedGroupUrl}/newEvent")
	public String newEvent(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl, EventPojo thymeleafEventPojo,
			@RequestParam("files") MultipartFile[] uploadedFiles) throws Exception {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();
		AccessPojo loggedUserAccessPojo = accessService.setLoggedUserAccessPojo(loggedUser, selectedGroup);

		// Business logic
		if (loggedUserAccessPojo.isGroupEventEdit() == true) {
			eventService.newEventOfficial(thymeleafEventPojo, selectedGroup, loggedUser, uploadedFiles);
			logService.logNewEvent(loggedUser, selectedGroup, thymeleafEventPojo);
		}

		return "redirect:" + selectedGroup.getUrl() + "/events/all";
	}

	@RequestMapping("/group/{selectedGroupUrl}/event/{selectedCategory}/{selectedEventNumber}")
	public String selectedEvent(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl,
			@PathVariable(value = "selectedCategory") String selectedCategory,
			@PathVariable(value = "selectedEventNumber") Long selectedEventNumber, Model model, PaginationPojo paginationPojo)
			throws Exception {

		// Preparing
		GroupsPojo selectedGroup = setGroupEnvironment(model, selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();

		EventPojo emptyEventPojo = new EventPojo();
		model.addAttribute("emptyEventPojo", emptyEventPojo);

		// Business logic
		EventPojo selectedEventPojo = eventService.findEventByGroupIDAndEventCategoryAndEventNumber(selectedGroup, selectedCategory,
				selectedEventNumber);
		model.addAttribute("selectedEventPojo", selectedEventPojo);

		ArrayList<String> joinableClassList = eventService.getAccessNameByAccessID(selectedEventPojo);
		model.addAttribute("joinableClassList", joinableClassList);

		ImgStoragePojo imgStoragePojoForComments = selectedEventPojo.getImgStoragePojo();
		model.addAttribute("imgStoragePojoForComments", imgStoragePojoForComments);

		EventParticipantPojo emptyEventParticipantPojo = new EventParticipantPojo();
		model.addAttribute("emptyEventParticipantPojo", emptyEventParticipantPojo);

		List<EventParticipantPojo> lobbyEventParticipantPojoList = eventService
				.findByEventIDAndStatusOrderByEventParticipantID(selectedEventPojo.getEventID(), "lobby");
		model.addAttribute("lobbyEventParticipantPojoList", lobbyEventParticipantPojoList);

		List<String> status = new ArrayList<String>();
		status.add("lobby");
		status.add("manually rejected");
		List<EventParticipantPojo> notLobbyEventParticipantPojoList = eventService
				.findByEventIDAndStatusNotInOrderByEventParticipantID(selectedEventPojo.getEventID(), status);
		model.addAttribute("notLobbyEventParticipantPojoList", notLobbyEventParticipantPojoList);

		String getEventLimit = eventService.getEventLimit(loggedUser, selectedEventPojo);
		model.addAttribute("getEventLimit", getEventLimit);

		String eventIsExpired = eventService.checkEventIsExpired(selectedEventPojo);
		model.addAttribute("eventIsExpired", eventIsExpired);

		String raffleStatus = eventService.checkRaffleStatus(selectedEventPojo);
		model.addAttribute("raffleStatus", raffleStatus);

		utilsService.addNumberOfViewsThis(selectedEventPojo.getImgStoragePojo());

		// Breadcrumbs
		List<String> breadcrumbNameList = new ArrayList<String>();
		List<String> breadcrumbUrlList = new ArrayList<String>();
		breadcrumbNameList.add(selectedGroup.getName());
		breadcrumbUrlList.add(selectedGroup.getUrl());
		breadcrumbNameList.add("Events");
		breadcrumbUrlList.add(selectedGroup.getUrl() + "/events/all");
		breadcrumbNameList.add(selectedEventPojo.getTitle());
		breadcrumbUrlList.add(selectedEventPojo.getUrl());
		setBreadcrumbs(breadcrumbNameList, breadcrumbUrlList, model);

		return "groupPages/eventMain";
	}

	@RequestMapping("/group/{selectedGroupUrl}/editEvent")
	public String editEvent(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl, EventPojo thymeleafEventPojo,
			@RequestParam("files") MultipartFile[] uploadedFiles) throws Exception {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();
		AccessPojo loggedUserAccessPojo = accessService.setLoggedUserAccessPojo(loggedUser, selectedGroup);

		// Business logic
		EventPojo selectedEventPojo = null;
		if (loggedUserAccessPojo.isGroupEventEdit() == true) {
			selectedEventPojo = eventService.editEventOfficial(thymeleafEventPojo, selectedGroup, loggedUser);
			logService.logEditEvent(loggedUser, selectedGroup, thymeleafEventPojo);
		}

		return "redirect:" + selectedGroup.getUrl() + "/event/" + selectedEventPojo.getCategory() + "/" + selectedEventPojo.getNumber();
	}

	@RequestMapping("/group/{selectedGroupUrl}/event/userApproved")
	public String eventUserApproved(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl, EventPojo thymeleafEventPojo,
			EventParticipantPojo thymeleafEventParticipantPojo) throws Exception {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();
		AccessPojo loggedUserAccessPojo = accessService.setLoggedUserAccessPojo(loggedUser, selectedGroup);

		// Business logic
		EventParticipantPojo selectedEventParticipantPojo = eventService
				.findByEventParticipantID(thymeleafEventParticipantPojo.getEventParticipantID());
		String returnString = "cantApprovThis";
		EventPojo selectedEventPojo = eventService.findSelectedEventPojo(selectedEventParticipantPojo.getEventID());

		if (loggedUserAccessPojo.isGroupEventEdit() == true && selectedEventPojo.getWinner().equals("Every participant")) {
			List<String> rewardItems = eventService.simpleEventManuallySubmissionApproval(selectedEventParticipantPojo, selectedEventPojo);
			messageService.simpleEventManuallySubmissionApproval(selectedEventParticipantPojo.getUsersPojo(), selectedEventPojo,
					rewardItems);
			returnString = "userApproved";
		}

		return "redirect:" + selectedGroup.getUrl() + "/event/" + selectedEventPojo.getCategory() + "/" + selectedEventPojo.getNumber()
				+ "?" + returnString;
	}

	@RequestMapping("/group/{selectedGroupUrl}/event/userRejected")
	public String eventUserRejected(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl, EventPojo thymeleafEventPojo,
			EventParticipantPojo thymeleafEventParticipantPojo,
			@RequestParam(required = false, name = "explanationForParticipantReject") String explanationForParticipantReject)
			throws Exception {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();
		AccessPojo loggedUserAccessPojo = accessService.setLoggedUserAccessPojo(loggedUser, selectedGroup);

		// Business logic
		EventParticipantPojo selectedEventParticipantPojo = eventService
				.findByEventParticipantID(thymeleafEventParticipantPojo.getEventParticipantID());
		String returnString = "cantApprovThis";
		EventPojo selectedEventPojo = eventService.findSelectedEventPojo(selectedEventParticipantPojo.getEventID());

		if (loggedUserAccessPojo.isGroupEventEdit() == true) {
			if (explanationForParticipantReject == null) {
				explanationForParticipantReject = "";
			}
			eventService.simpleEventManuallySubmissionRejected(selectedEventParticipantPojo, selectedEventPojo);
			messageService.simpleEventManuallySubmissionRejected(selectedEventParticipantPojo.getUsersPojo(), selectedEventPojo,
					explanationForParticipantReject);
			returnString = "userRejected";
		}

		return "redirect:" + selectedGroup.getUrl() + "/event/" + selectedEventPojo.getCategory() + "/" + selectedEventPojo.getNumber()
				+ "?" + returnString;
	}

//########################################################################################################################################################################################
// __Members handlers
//########################################################################################################################################################################################
	@RequestMapping("/group/{selectedGroupUrl}/members")
	public String membersMainPage(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl, Model model,
			PaginationPojo paginationPojo) throws Exception {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();

		// Business logic
		List<Long> loggedUserAccessIDList = new ArrayList<>();
		if (loggedUser != null) {
			for (int i = 0; i < loggedUser.getAccessPojoList().size(); i++) {
				loggedUserAccessIDList.add(loggedUser.getAccessPojoList().get(i).getAccessID());
			}
		}
		model.addAttribute("loggedUserAccessIDList", loggedUserAccessIDList);

		List<Long> loggedUserLobbyAccessIDList = new ArrayList<>();
		if (loggedUser != null) {
			for (int i = 0; i < loggedUser.getAccessPojoLobbyList().size(); i++) {
				loggedUserLobbyAccessIDList.add(loggedUser.getAccessPojoLobbyList().get(i).getAccessID());
			}
		}
		model.addAttribute("loggedUserLobbyAccessIDList", loggedUserLobbyAccessIDList);

		List<AccessPojo> accessPojoList = accessService.getAccessPojoList(selectedGroup);
		model.addAttribute("accessPojoList", accessPojoList);

		AccessPojo emptyAccessPojo = new AccessPojo();
		model.addAttribute("emptyAccessPojo", emptyAccessPojo);

		List<UsersPojo> membersAndUsersPojoList = accessService.getGroupMembersAndAllEnabledUser(selectedGroup);
		model.addAttribute("membersAndUsersPojoList", membersAndUsersPojoList);

		List<UsersPojo> membersUsersPojoListSize = accessService.getMembersUsersPojoListByAccessPojoListInThisGroup(selectedGroup);
		model.addAttribute("membersUsersPojoListSize", membersUsersPojoListSize.size());

		// Breadcrumbs
		List<String> breadcrumbNameList = new ArrayList<String>();
		List<String> breadcrumbUrlList = new ArrayList<String>();
		breadcrumbNameList.add(selectedGroup.getName());
		breadcrumbUrlList.add(selectedGroup.getUrl());
		breadcrumbNameList.add("Members");
		breadcrumbUrlList.add(selectedGroup.getUrl() + "/members");
		setBreadcrumbs(breadcrumbNameList, breadcrumbUrlList, model);

		return "groupPages/membersMain";
	}

	@RequestMapping("/group/{selectedGroupUrl}/members/newUserClass")
	public String newUserClass(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl, Model model,
			AccessPojo thymeleafAccessPojo) throws Exception {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();
		AccessPojo loggedUserAccessPojo = accessService.setLoggedUserAccessPojo(loggedUser, selectedGroup);

		// Business logic
		if (loggedUserAccessPojo.isGroupMembersEdit() == true) {
			accessService.newUserClass(loggedUser, selectedGroup, thymeleafAccessPojo);
		}

		return "redirect:" + selectedGroup.getUrl() + "/members";
	}

	@RequestMapping("/group/{selectedGroupUrl}/members/joinClass")
	public String joinClass(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl, Model model, AccessPojo thymeleafAccessPojo)
			throws Exception {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();
		AccessPojo selectedAccessPojo = accessService.findByAccessID(thymeleafAccessPojo.getAccessID());

		// Business logic
		if (loggedUser != null && selectedAccessPojo.isAdmissionOpen() && selectedAccessPojo.isAdmissionAuto()) {
			accessService.joinClass(loggedUser, thymeleafAccessPojo);
		}

		if (loggedUser != null && selectedAccessPojo.isAdmissionOpen() && !selectedAccessPojo.isAdmissionAuto()) {
			accessService.joinClassLobby(loggedUser, thymeleafAccessPojo);
		}

		return "redirect:" + selectedGroup.getUrl() + "/members";
	}

//########################################################################################################################################################################################
// __PayPal handlers
//########################################################################################################################################################################################			
	public static final String SUCCESS_URL = "pay/succes";
	public static final String CANCEL_URL = "pay/cancel";

	@RequestMapping("/group/paypal/pay")
	public String paypal(Model model) throws Exception {

		return "/paypal";
	}

	@PostMapping("/pay")
	public String payment(@ModelAttribute("order") Order order) {
		UpgradePojo upgradePojo = upgradeService.getUpgradePojo(order.getDescription());
		if (upgradePojo.getType().equals("Group upgrade with coin") || upgradePojo.getType().equals("User upgrade with coin")) {
			UpgradeService.setUpgradeByPaymentDescription(order.getDescription());
			return "redirect:/";
		}

		Payment payment = null;
		try {
			payment = paypalService.createPayment(order.getPrice(), order.getCurrency(), order.getMethod(), order.getIntent(),
					order.getDescription(), "http://www.myarpg.com/" + CANCEL_URL, "http://www.myarpg.com/" + SUCCESS_URL);
			for (Links link : payment.getLinks()) {
				if (link.getRel().equals("approval_url")) {
					return "redirect:" + link.getHref();
				}
			}

		} catch (PayPalRESTException e) {
			e.printStackTrace();
		}
		payment = null;
		return "redirect:/";
	}

	@GetMapping(value = CANCEL_URL)
	public String cancelPay() {
		return "paypalCancel";
	}

	@GetMapping(value = SUCCESS_URL)
	public String successPay(@RequestParam("paymentId") String paymentId, @RequestParam("PayerID") String payerId,
			@RequestParam("token") String token) {
		try {
			Payment payment = new Payment();
			payment.setId(paymentId);
			payment = paypalService.executePayment(paymentId, payerId);

			UpgradeService.setUpgradeByPaymentDescription(payment.getTransactions().get(payment.getTransactions().size() - 1).getDescription());

			if (payment.getState().equals("approved")) {
				payment = null;
				return "paypalSuccess";
			}
		} catch (PayPalRESTException e) {
		}
		return "redirect:/";
	}

//########################################################################################################################################################################################
// __BankPage handlers
//########################################################################################################################################################################################		
	@RequestMapping("/group/{selectedGroupUrl}/bank")
	public String bankPage(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl, Model model, PaginationPojo paginationPojo)
			throws Exception {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();

		// Business logic
		List<BankPojo> newBankPojoList = bankService.getNewItemsSelectAsChangedAndSetUnchanged(loggedUser, selectedGroup);
		model.addAttribute("newBankPojoList", newBankPojoList);

		// Breadcrumbs
		List<String> breadcrumbNameList = new ArrayList<String>();
		List<String> breadcrumbUrlList = new ArrayList<String>();
		breadcrumbNameList.add(selectedGroup.getName());
		breadcrumbUrlList.add(selectedGroup.getUrl());
		breadcrumbNameList.add("Bank");
		breadcrumbUrlList.add(selectedGroup.getUrl() + "/bank");
		setBreadcrumbs(breadcrumbNameList, breadcrumbUrlList, model);
		// -

		return "groupPages/bankMain";
	}

//########################################################################################################################################################################################
// __Comments handlers
//########################################################################################################################################################################################	
	@RequestMapping("/group/{selectedGroupUrl}/hideComment")
	public String hideComment(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl, Model model,
			CommentPojo thymeleafCommentPojo, @RequestParam(required = false, name = "autoRedirectHere") String autoRedirectHere)
			throws Exception {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();
		AccessPojo loggedUserAccessPojo = accessService.setLoggedUserAccessPojo(loggedUser, selectedGroup);

		// Business logic
		if (loggedUserAccessPojo.isGroupCommentHide()) {
			groupService.hideComment(selectedGroup, loggedUser, thymeleafCommentPojo);
		}

		return "redirect:" + autoRedirectHere;
	}

//########################################################################################################################################################################################
// __Private messages and auto messages handlers
//########################################################################################################################################################################################		
	@RequestMapping("/group/{selectedGroupUrl}/messages")
	public String messages(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl, Model model, PaginationPojo paginationPojo,
			MessagePojo thymeleafMessagePojo) throws Exception {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();

		MessagePojo emptyMessagePojo = new MessagePojo();
		model.addAttribute("emptyMessagePojo", emptyMessagePojo);

		// Business logic
		if (thymeleafMessagePojo.getMessageID() != null) {
			MessagePojo selectedMessagePojo = messageService.selectedMessage(loggedUser, thymeleafMessagePojo);
			if (selectedMessagePojo != null) {
				model.addAttribute("selectedMessagePojo", selectedMessagePojo);
			}
		}

		Integer privateMessagesCount = 0;
		for (int i = 0; i < loggedUser.getReciverMessagePojo().size(); i++) {
			if (loggedUser.getReciverMessagePojo().get(i).getType().equals("private")
					&& loggedUser.getReciverMessagePojo().get(i).isUnread() == true) {
				privateMessagesCount++;
			}
		}
		model.addAttribute("privateMessagesCount", privateMessagesCount);

		Integer robotMessagesCount = 0;
		for (int i = 0; i < loggedUser.getReciverMessagePojo().size(); i++) {
			if (loggedUser.getReciverMessagePojo().get(i).getType().equals("robot")
					&& loggedUser.getReciverMessagePojo().get(i).isUnread() == true) {
				robotMessagesCount++;
			}
		}
		model.addAttribute("robotMessagesCount", robotMessagesCount);

		List<UsersPojo> usersPojoList = userService.findByUserEnabledTrueOrderByUserNameAsc();
		model.addAttribute("usersPojoList", usersPojoList);

		// Breadcrumbs
		List<String> breadcrumbNameList = new ArrayList<String>();
		List<String> breadcrumbUrlList = new ArrayList<String>();
		breadcrumbNameList.add("Messages");
		breadcrumbUrlList.add(selectedGroup.getUrl() + "/messages");
		setBreadcrumbs(breadcrumbNameList, breadcrumbUrlList, model);

		return "groupPages/messagesMain";
	}

	@RequestMapping("/group/{selectedGroupUrl}/newMessage")
	public String newMessage(@PathVariable(value = "selectedGroupUrl") String selectedGroupUrl, Model model, PaginationPojo paginationPojo,
			MessagePojo thymeleafMessagePojo, @RequestParam(required = false, name = "messageTo") String messageTo,
			@RequestParam(required = false, name = "newMessageSummernote") String newMessageSummernote) throws Exception {

		// Preparing
		GroupsPojo selectedGroup = groupService.getGroupsPojoBySelectedGroupUrl(selectedGroupUrl);
		UsersPojo loggedUser = userService.loggedUserPojo();

		// Business logic
		String returnString = messageService.newMessage(loggedUser, messageTo, thymeleafMessagePojo, newMessageSummernote);

		if (returnString.equals("ok")) {
			return "redirect:" + selectedGroup.getUrl() + "/messages?messageWasSent";
		}

		if (returnString.equals("userNotFound")) {
			return "redirect:" + selectedGroup.getUrl() + "/messages?userNotFound";
		}

		return "redirect:" + selectedGroup.getUrl() + "/messages";
	}

//########################################################################################################################################################################################
// __User pages
//########################################################################################################################################################################################		
	@RequestMapping("/user/{userName}")
	public String userGallery(@PathVariable(value = "userName") String userName, Model model, PaginationPojo paginationPojo)
			throws Exception {

		// Preparing
		setUserEnvironment(model);

		// Breadcrumb
		List<String> breadcrumbNameList = new ArrayList<String>();
		List<String> breadcrumbUrlList = new ArrayList<String>();
		breadcrumbNameList.add(userName);
		breadcrumbUrlList.add("/user/" + userName);
		setBreadcrumbs(breadcrumbNameList, breadcrumbUrlList, model);
		// -

		return "user/home";
	}

	@RequestMapping("/user/{userName}/editAboutMe")
	public String editAboutMe(@PathVariable(value = "userName") String userName, Model model,
			@RequestParam(required = false, name = "editAboutMeSummernote") String editAboutMeSummernote) throws Exception {

		// Preparing
		UsersPojo loggedUser = userService.loggedUserPojo();
		UsersPojo selectedUsersPojo = userService.findByuserNameIgnoreCase(userName);

		// Business logic
		if (loggedUser != null && loggedUser.getUserID() == selectedUsersPojo.getUserID()) {
			userService.editAboutMe(loggedUser, editAboutMeSummernote);
		}

		return "redirect:/user/" + loggedUser.getUserName();
	}

//########################################################################################################################################################################################
// __Repetitive codes
//########################################################################################################################################################################################		
	private UsersPojo setUserEnvironment(Model model) {
		UsersPojo loggedUser = userService.loggedUserPojo();
		model.addAttribute("loggedUser", loggedUser);
		List<WarningPojo> warningPojo = utilsService.findAllWarning();
		model.addAttribute("warningPojo", warningPojo);
		return loggedUser;
	}

	private GroupsPojo setGroupEnvironment(Model model, String groupUrlName) {
		GroupsPojo selectedGroup = null;
		String groupUrlNameWithGroupPath = "/group/" + groupUrlName;
		try {
			selectedGroup = groupService.findByUrlIgnoreCase(groupUrlNameWithGroupPath);
		} catch (Exception e) {
		}
		model.addAttribute("selectedGroup", selectedGroup);
		UsersPojo loggedUser = userService.loggedUserPojo();
		AccessPojo loggedUserAccessPojo = accessService.setLoggedUserAccessPojo(loggedUser, selectedGroup);
		model.addAttribute("loggedUserAccessPojo", loggedUserAccessPojo);
		model.addAttribute("loggedUser", loggedUser);
		List<WarningPojo> warningPojo = utilsService.findAllWarning();
		model.addAttribute("warningPojo", warningPojo);

		return selectedGroup;
	}

	private void setBreadcrumbs(List<String> breadcrumbNameList, List<String> breadcrumbUrlList, Model model) {
		for (int i = 0; i < breadcrumbNameList.size(); i++) {
			model.addAttribute("breadcrumb" + (i + 1) + "Name", breadcrumbNameList.get(i));
			model.addAttribute("breadcrumb" + (i + 1) + "Url", breadcrumbUrlList.get(i));
		}
	}

} // End of HomeController
