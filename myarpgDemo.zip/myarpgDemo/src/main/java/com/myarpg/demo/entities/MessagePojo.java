package com.myarpg.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.joda.time.DateTime;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class MessagePojo {

	@Id
	@GeneratedValue
	private Long messageID;
	private String type;
	private String subject;
	private boolean unread;
	
	@Column(length = 4000)
	private String message;

	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm")
	private DateTime sentTime;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="senderUsersPojo")
	private UsersPojo senderUsersPojo;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="reciverUsersPojo")
	private UsersPojo reciverUsersPojo;
	
	public MessagePojo() {
	}

	public Long getMessageID() {
		return messageID;
	}

	public void setMessageID(Long messageID) {
		this.messageID = messageID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public DateTime getSentTime() {
		return sentTime;
	}

	public void setSentTime(DateTime sentTime) {
		this.sentTime = sentTime;
	}

	public boolean isUnread() {
		return unread;
	}

	public void setUnread(boolean unread) {
		this.unread = unread;
	}

	public UsersPojo getSenderUsersPojo() {
		return senderUsersPojo;
	}

	public void setSenderUsersPojo(UsersPojo senderUsersPojo) {
		this.senderUsersPojo = senderUsersPojo;
	}

	public UsersPojo getReciverUsersPojo() {
		return reciverUsersPojo;
	}

	public void setReciverUsersPojo(UsersPojo reciverUsersPojo) {
		this.reciverUsersPojo = reciverUsersPojo;
	}
	
}
