package com.myarpg.demo.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;

import org.joda.time.DateTime;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class ImgStoragePojo {

	@Id
	@GeneratedValue
	private Long imgStorageID;

	private String title;
	private String imageKey;
	private Long categoryID;
	private String displaySize;
	private String serverPath;
	private String extension;
	private boolean allowed;
	private boolean showInGallery;

	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm:ss")
	private DateTime uploadTime;

	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm")
	private DateTime publishedTime;
	private String tags;
	private String warnings;
	private String spoilers;
	private String matureContents;
	
	private String topicType;
	private String topicLink;
	
	@Column(length=5000) 
	private String artistComment;
	private Long sizeInkb;

	private String SpringAdvSec5Type;
	
	@ManyToOne(cascade = CascadeType.ALL)
	private GroupsPojo groupsPojo;
	
	@ManyToOne(cascade = CascadeType.ALL)
	private UsersPojo usersPojo;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "imgStorageID", nullable = true)
	@OrderBy("position ASC")
	private List<CommentPojo> commentPojo;

	private Long numberOfViews;
	
	private Long numberOfComments;
	
	public ImgStoragePojo() {
	}

	public Long getImgStorageID() {
		return imgStorageID;
	}

	public void setImgStorageID(Long imgStorageID) {
		this.imgStorageID = imgStorageID;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getImageKey() {
		return imageKey;
	}

	public void setImageKey(String imageKey) {
		this.imageKey = imageKey;
	}

	public Long getCategoryID() {
		return categoryID;
	}

	public void setCategoryID(Long categoryID) {
		this.categoryID = categoryID;
	}

	public String getDisplaySize() {
		return displaySize;
	}

	public void setDisplaySize(String displaySize) {
		this.displaySize = displaySize;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public boolean isAllowed() {
		return allowed;
	}

	public void setAllowed(boolean allowed) {
		this.allowed = allowed;
	}

	public DateTime getUploadTime() {
		return uploadTime;
	}

	public void setUploadTime(DateTime uploadTime) {
		this.uploadTime = uploadTime;
	}

	public DateTime getPublishedTime() {
		return publishedTime;
	}

	public void setPublishedTime(DateTime publishedTime) {
		this.publishedTime = publishedTime;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public String getWarnings() {
		return warnings;
	}

	public void setWarnings(String warnings) {
		this.warnings = warnings;
	}

	public String getSpoilers() {
		return spoilers;
	}

	public void setSpoilers(String spoilers) {
		this.spoilers = spoilers;
	}

	public String getMatureContents() {
		return matureContents;
	}

	public void setMatureContents(String matureContents) {
		this.matureContents = matureContents;
	}

	public String getArtistComment() {
		return artistComment;
	}

	public void setArtistComment(String artistComment) {
		this.artistComment = artistComment;
	}

	public Long getSizeInkb() {
		return sizeInkb;
	}

	public void setSizeInkb(Long sizeInkb) {
		this.sizeInkb = sizeInkb;
	}

	public String getSpringAdvSec5Type() {
		return SpringAdvSec5Type;
	}

	public void setSpringAdvSec5Type(String springAdvSec5Type) {
		SpringAdvSec5Type = springAdvSec5Type;
	}

	public String getServerPath() {
		return serverPath;
	}

	public void setServerPath(String serverPath) {
		this.serverPath = serverPath;
	}

	public boolean isShowInGallery() {
		return showInGallery;
	}

	public void setShowInGallery(boolean showInGallery) {
		this.showInGallery = showInGallery;
	}

	public UsersPojo getUsersPojo() {
		return usersPojo;
	}

	public void setUsersPojo(UsersPojo usersPojo) {
		this.usersPojo = usersPojo;
	}

	public GroupsPojo getGroupsPojo() {
		return groupsPojo;
	}

	public void setGroupsPojo(GroupsPojo groupsPojo) {
		this.groupsPojo = groupsPojo;
	}

	public String getTopicLink() {
		return topicLink;
	}

	public void setTopicLink(String topicLink) {
		this.topicLink = topicLink;
	}

	public String getTopicType() {
		return topicType;
	}

	public void setTopicType(String topicType) {
		this.topicType = topicType;
	}

	public List<CommentPojo> getCommentPojo() {
		return commentPojo;
	}

	public void setCommentPojo(List<CommentPojo> commentPojo) {
		this.commentPojo = commentPojo;
	}

	public Long getNumberOfViews() {
		return numberOfViews;
	}

	public void setNumberOfViews(Long numberOfViews) {
		this.numberOfViews = numberOfViews;
	}

	public Long getNumberOfComments() {
		return numberOfComments;
	}

	public void setNumberOfComments(Long numberOfComments) {
		this.numberOfComments = numberOfComments;
	}


	
	

}
