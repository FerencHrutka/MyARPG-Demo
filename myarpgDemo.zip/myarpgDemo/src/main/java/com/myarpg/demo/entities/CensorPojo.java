package com.myarpg.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class CensorPojo {

	@GeneratedValue
	@Id
	private Long censorID;
	private String bannedWordsForUsername;

	public CensorPojo() {
	}

	public Long getCensorID() {
		return censorID;
	}

	public void setCensorID(Long censorID) {
		this.censorID = censorID;
	}

	public String getBannedWordsForUsername() {
		return bannedWordsForUsername;
	}

	public void setBannedWordsForUsername(String bannedWordsForUsername) {
		this.bannedWordsForUsername = bannedWordsForUsername;
	}

}
