package com.myarpg.demo.service;

import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.myarpg.demo.entities.CensorPojo;
import com.myarpg.demo.entities.CharactersPojo;
import com.myarpg.demo.entities.EventPojo;
import com.myarpg.demo.entities.GroupsPojo;
import com.myarpg.demo.entities.ImgStoragePojo;
import com.myarpg.demo.entities.ItemCategoriesPojo;
import com.myarpg.demo.entities.ItemsPojo;
import com.myarpg.demo.entities.MatchersPojo;
import com.myarpg.demo.entities.SpeciesPojo;
import com.myarpg.demo.entities.UsersPojo;
import com.myarpg.demo.entities.WarningPojo;
import com.myarpg.demo.repository.CensorRepository;
import com.myarpg.demo.repository.CharactersRepository;
import com.myarpg.demo.repository.ImgStorageRepository;
import com.myarpg.demo.repository.ItemCategoriesRepository;
import com.myarpg.demo.repository.ItemsRepository;
import com.myarpg.demo.repository.MatchersRepository;
import com.myarpg.demo.repository.SpeciesRepository;
import com.myarpg.demo.repository.WarningRepository;

@Service
public class UtilsService {

	MatchersRepository matchersRepository;

	@Autowired
	public void setMatchersRepository(MatchersRepository matchersRepository) {
		this.matchersRepository = matchersRepository;
	}

	UsersService usersService;

	@Autowired
	public void setUsersService(UsersService usersService) {
		this.usersService = usersService;
	}

	ImgStorageRepository imgStorageRepository;

	@Autowired
	public void setImgStorageRepository(ImgStorageRepository imgStorageRepository) {
		this.imgStorageRepository = imgStorageRepository;
	}

	private SpeciesRepository speciesRepository;

	@Autowired
	public void setSpeciesRepository(SpeciesRepository speciesRepository) {
		this.speciesRepository = speciesRepository;
	}

	private CharactersRepository charactersRepository;

	@Autowired
	public void setCharactersRepository(CharactersRepository charactersRepository) {
		this.charactersRepository = charactersRepository;
	}

	ItemsRepository itemsRepository;

	@Autowired
	public void setItemsRepository(ItemsRepository itemsRepository) {
		this.itemsRepository = itemsRepository;
	}

	ItemCategoriesRepository itemCategoriesRepository;

	@Autowired
	public void setItemCategoriesRepository(ItemCategoriesRepository itemCategoriesRepository) {
		this.itemCategoriesRepository = itemCategoriesRepository;
	}

	CensorRepository censorRepository;

	@Autowired
	public void setCensorRepository(CensorRepository censorRepository) {
		this.censorRepository = censorRepository;
	}

	WarningRepository warningRepository;

	@Autowired
	public void setWarningRepository(WarningRepository warningRepository) {
		this.warningRepository = warningRepository;
	}

	public static String uploadDirectory() {
		InetAddress myHost = null;
		try {
			myHost = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

		if (myHost.getHostName().equals("VAS")) {
			return System.getProperty("user.dir") + "/static";
		}

		return "/opt/tomcat/webapps/ROOT"; 
	}

	public List<MatchersPojo> getMatchers() {
		return matchersRepository.findAll();
	}

	public void uploadNewSpeciesOrCharacter(String funktion, MultipartFile[] uploadedFiles, GroupsPojo selectedGroup,
			SpeciesPojo speciesPojo, CharactersPojo charactersPojo) {
		ImgStoragePojo selectedImgStoragePojo = null;

		String imageKey = null;
		if (funktion.equals("Species")) {
			imageKey = selectedGroup.getName().replaceAll("[^\\p{Alpha}\\p{Digit}]+", "").toLowerCase() + "_" + speciesPojo.getUrl() + "_"
					+ "cover";
		}
		if (funktion.equals("Character")) {
			imageKey = selectedGroup.getName().replaceAll("[^\\p{Alpha}\\p{Digit}]+", "").toLowerCase() + "_" + speciesPojo.getUrl() + "_"
					+ charactersPojo.getNumber().toString();
		}

		try {
			selectedImgStoragePojo = imgStorageRepository.findByImageKey(imageKey);
		} catch (Exception e) {
		}

		if (selectedImgStoragePojo == null) {
			selectedImgStoragePojo = new ImgStoragePojo();
			selectedImgStoragePojo.setServerPath("");
		}

		if (selectedImgStoragePojo.getServerPath().contains("/img/")) {
			String fullPath = uploadDirectory() + selectedImgStoragePojo.getServerPath();
			Path fileNameAndPath = Paths.get(fullPath);
			File file = new File(fileNameAndPath.toString());
			file.delete();
		}

		MultipartFile firstMultipartFile = uploadedFiles[0];

		if (firstMultipartFile.getSize() != 0) {

			String fullPath = uploadDirectory() + "/img" + selectedGroup.getUrl() + "/" + speciesPojo.getUrl();
			new File(fullPath).mkdirs();

			String fileNameForFileExtensionCheck = firstMultipartFile.getOriginalFilename();
			String fileNameConversionToReplaceAllAndLowerCase = fileNameForFileExtensionCheck.replaceAll(" ", "_").toLowerCase();
			String dotExtension = fileNameConversionToReplaceAllAndLowerCase
					.substring(fileNameConversionToReplaceAllAndLowerCase.lastIndexOf("."));

			selectedImgStoragePojo.setUploadTime(DateTime.now());
			selectedImgStoragePojo.setExtension(dotExtension);
			selectedImgStoragePojo.setGroupsPojo(selectedGroup);
			selectedImgStoragePojo.setSizeInkb(firstMultipartFile.getSize() / 1024);
			selectedImgStoragePojo.setAllowed(true);
			selectedImgStoragePojo.setShowInGallery(false);
			selectedImgStoragePojo.setNumberOfViews(0L);
			selectedImgStoragePojo.setNumberOfComments(0L);

			UsersPojo loggedUser = usersService.loggedUserPojo();
			selectedImgStoragePojo.setUsersPojo(loggedUser);

			String fileName = null;
			if (funktion.equals("Species")) {
				fileName = speciesPojo.getUrl() + "Cover";

				selectedImgStoragePojo.setTopicType("species");
				selectedImgStoragePojo.setTopicLink(selectedGroup.getUrl() + "/masterlist/" + speciesPojo.getUrl());
			}

			if (funktion.equals("Character")) {
				fileName = speciesPojo.getUrl() + "_" + charactersPojo.getNumber().toString();

				selectedImgStoragePojo.setTopicType("character");
				selectedImgStoragePojo.setTopicLink(
						selectedGroup.getUrl() + "/character/" + speciesPojo.getUrl() + "/" + charactersPojo.getNumber().toString());
			}

			String serverPath = "/img" + selectedGroup.getUrl() + "/" + speciesPojo.getUrl() + "/" + fileName + dotExtension;
			selectedImgStoragePojo.setServerPath(serverPath);
			Path fileNameAndPath = Paths.get(fullPath, fileName + dotExtension);

			try {
				Files.write(fileNameAndPath, firstMultipartFile.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		selectedImgStoragePojo.setImageKey(imageKey);

		if (funktion.equals("Species")) {
			speciesPojo.setImgStoragePojo(selectedImgStoragePojo);
			speciesRepository.save(speciesPojo);
		}
		if (funktion.equals("Character")) {
			charactersPojo.setImgStoragePojo(selectedImgStoragePojo);
			charactersRepository.save(charactersPojo);
		}

	}

	public ImgStoragePojo uploadItemCategoriesOrItems(String funktion, MultipartFile[] uploadedFiles, GroupsPojo selectedGroup,
			ItemCategoriesPojo itemCategoriesPojo, ItemsPojo itemsPojo) {
		ImgStoragePojo selectedImgStoragePojo = null;

		String imageKey = null;
		if (funktion.equals("ItemCategories")) {
			imageKey = selectedGroup.getName().replaceAll("[^\\p{Alpha}\\p{Digit}]+", "").toLowerCase() + "_" + itemCategoriesPojo.getUrl()
					+ "_" + "cover";
		}
		if (funktion.equals("Items")) {
			imageKey = selectedGroup.getName().replaceAll("[^\\p{Alpha}\\p{Digit}]+", "").toLowerCase() + "_" + itemCategoriesPojo.getUrl()
					+ "_" + itemsPojo.getNumber().toString();
		}

		try {
			selectedImgStoragePojo = imgStorageRepository.findByImageKey(imageKey);
		} catch (Exception e) {
		}

		if (selectedImgStoragePojo == null) {
			selectedImgStoragePojo = new ImgStoragePojo();
			selectedImgStoragePojo.setServerPath("");
		}

		if (selectedImgStoragePojo.getServerPath().contains("/img/")) {
			String fullPath = uploadDirectory() + selectedImgStoragePojo.getServerPath();
			Path fileNameAndPath = Paths.get(fullPath);
			File file = new File(fileNameAndPath.toString());
			file.delete();
		}

		MultipartFile firstMultipartFile = uploadedFiles[0];

		if (firstMultipartFile.getSize() != 0) {

			String fullPath = uploadDirectory() + "/img" + selectedGroup.getUrl() + "/items/" + itemCategoriesPojo.getUrl();
			new File(fullPath).mkdirs();

			String fileNameForFileExtensionCheck = firstMultipartFile.getOriginalFilename();
			String fileNameConversionToReplaceAllAndLowerCase = fileNameForFileExtensionCheck.replaceAll(" ", "_").toLowerCase();
			String dotExtension = fileNameConversionToReplaceAllAndLowerCase
					.substring(fileNameConversionToReplaceAllAndLowerCase.lastIndexOf("."));

			selectedImgStoragePojo.setUploadTime(DateTime.now());
			selectedImgStoragePojo.setExtension(dotExtension);
			selectedImgStoragePojo.setGroupsPojo(selectedGroup);
			selectedImgStoragePojo.setSizeInkb(firstMultipartFile.getSize() / 1024);
			selectedImgStoragePojo.setAllowed(true);
			selectedImgStoragePojo.setShowInGallery(false);
			selectedImgStoragePojo.setNumberOfViews(0L);
			selectedImgStoragePojo.setNumberOfComments(0L);

			UsersPojo loggedUser = usersService.loggedUserPojo();
			selectedImgStoragePojo.setUsersPojo(loggedUser);

			String fileName = null;
			if (funktion.equals("ItemCategories")) {
				fileName = itemCategoriesPojo.getUrl() + "Cover";

				selectedImgStoragePojo.setTopicType("itemcategories");
				selectedImgStoragePojo.setTopicLink(selectedGroup.getUrl() + "/items/" + itemCategoriesPojo.getUrl());
			}

			if (funktion.equals("Items")) {
				fileName = itemCategoriesPojo.getUrl() + "_" + itemsPojo.getNumber().toString();

				selectedImgStoragePojo.setTopicType("items");
				selectedImgStoragePojo.setTopicLink(
						selectedGroup.getUrl() + "/item/" + itemCategoriesPojo.getUrl() + "/" + itemsPojo.getNumber().toString());
			}

			String serverPath = "/img" + selectedGroup.getUrl() + "/items/" + itemCategoriesPojo.getUrl() + "/" + fileName + dotExtension;
			selectedImgStoragePojo.setServerPath(serverPath);
			Path fileNameAndPath = Paths.get(fullPath, fileName + dotExtension);

			try {
				Files.write(fileNameAndPath, firstMultipartFile.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		selectedImgStoragePojo.setImageKey(imageKey);

		if (funktion.equals("ItemCategories")) {
			itemCategoriesPojo.setImgStoragePojo(selectedImgStoragePojo);
			itemCategoriesRepository.save(itemCategoriesPojo);
		}
		if (funktion.equals("Items")) {
			itemsPojo.setImgStoragePojo(selectedImgStoragePojo);
			itemsRepository.save(itemsPojo);
		}

		return selectedImgStoragePojo;
	}

	public ImgStoragePojo uploadEventCover(MultipartFile[] uploadedFiles, GroupsPojo selectedGroup, EventPojo thymeleafEventPojo) {

		String imageKey = thymeleafEventPojo.getType() + "_" + thymeleafEventPojo.getNumber() + "_cover";

		ImgStoragePojo selectedImgStoragePojo = null;
		try {
			selectedImgStoragePojo = imgStorageRepository.findByGroupsPojoGroupIDAndImageKey(selectedGroup.getGroupID(), imageKey);
		} catch (Exception e) {
		}

		if (selectedImgStoragePojo == null) {
			selectedImgStoragePojo = new ImgStoragePojo();
			selectedImgStoragePojo.setServerPath("");
		}

		if (selectedImgStoragePojo.getServerPath().contains("/img/")) {
			String fullPath = uploadDirectory() + selectedImgStoragePojo.getServerPath();
			Path fileNameAndPath = Paths.get(fullPath);
			File file = new File(fileNameAndPath.toString());
			file.delete();
		}

		MultipartFile firstMultipartFile = uploadedFiles[0];

		if (firstMultipartFile.getSize() != 0) {

			String fullPath = uploadDirectory() + "/img" + selectedGroup.getUrl() + "/event/" + thymeleafEventPojo.getCategory() + "/"
					+ thymeleafEventPojo.getNumber();
			new File(fullPath).mkdirs();

			String fileNameForFileExtensionCheck = firstMultipartFile.getOriginalFilename();
			String fileNameConversionToReplaceAllAndLowerCase = fileNameForFileExtensionCheck.replaceAll(" ", "_").toLowerCase();
			String dotExtension = fileNameConversionToReplaceAllAndLowerCase
					.substring(fileNameConversionToReplaceAllAndLowerCase.lastIndexOf("."));

			selectedImgStoragePojo.setUploadTime(DateTime.now());
			selectedImgStoragePojo.setExtension(dotExtension);
			selectedImgStoragePojo.setGroupsPojo(selectedGroup);
			selectedImgStoragePojo.setSizeInkb(firstMultipartFile.getSize() / 1024);
			selectedImgStoragePojo.setAllowed(true);
			selectedImgStoragePojo.setShowInGallery(false);
			selectedImgStoragePojo.setNumberOfViews(0L);
			selectedImgStoragePojo.setNumberOfComments(0L);

			UsersPojo loggedUser = usersService.loggedUserPojo();
			selectedImgStoragePojo.setUsersPojo(loggedUser);

			String fileName = imageKey;
			String serverPath = "/img" + selectedGroup.getUrl() + "/event/" + thymeleafEventPojo.getCategory() + "/"
					+ thymeleafEventPojo.getNumber() + "/" + thymeleafEventPojo.getType() + "_" + thymeleafEventPojo.getNumber() + "_cover"
					+ dotExtension;
			selectedImgStoragePojo.setServerPath(serverPath);
			Path fileNameAndPath = Paths.get(fullPath, fileName + dotExtension);

			selectedImgStoragePojo.setTopicType("event");
			selectedImgStoragePojo.setTopicLink(selectedGroup.getUrl() + "/event/" + thymeleafEventPojo.getCategory() + "/"
					+ thymeleafEventPojo.getNumber().toString());

			try {
				Files.write(fileNameAndPath, firstMultipartFile.getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		selectedImgStoragePojo.setImageKey(imageKey);

		imgStorageRepository.save(selectedImgStoragePojo);

		return selectedImgStoragePojo;
	}

	public void saveThisImgStoragePojo(ImgStoragePojo selectedImgStoragePojo) {
		imgStorageRepository.save(selectedImgStoragePojo);
	}

	public Boolean userNameCensorCheck(String userName) {

		CensorPojo censorPojo = null;

		String[] splited = userName.toLowerCase().split("\\s+");

		for (int i = 0; i < splited.length; i++) {
			try {
				censorPojo = censorRepository.findByBannedWordsForUsername(splited[i]);
			} catch (Exception e) {
			}

			if (censorPojo != null) {
				return false;
			}
		}

		try {
			censorPojo = censorRepository.findByBannedWordsForUsername(userName.toLowerCase());
		} catch (Exception e) {
		}
		if (censorPojo != null) {
			return false;
		}

		return true;
	}

	public List<WarningPojo> findAllWarning() {
		List<WarningPojo> warningPojo = warningRepository.findAllByOrderByWarningIDDesc();

		if (!warningPojo.isEmpty()) {
			if (warningPojo.get(0).getEnd().isBeforeNow()) {
				warningRepository.delete(warningPojo.get(0));
			}
		}

		return warningPojo;
	}

	public List<ImgStoragePojo> findFirst20ByTopicTypeOrderByImgStorageIDDesc(String topicType) {
		return imgStorageRepository.findFirst20ByTopicTypeOrderByImgStorageIDDesc(topicType);
	}

	public List<ImgStoragePojo> findByTopicTypeOrderByImgStorageIDDesc(String topicType, PageRequest pageRequest) {
		return imgStorageRepository.findByTopicTypeOrderByImgStorageIDDesc(topicType, pageRequest);
	}

	public Integer countByTopicType(String string) {
		return imgStorageRepository.countByTopicType(string);
	}

	public void addNumberOfViewsThis(ImgStoragePojo imgStoragePojo) {
		if (imgStoragePojo.getNumberOfViews() == null) {
			imgStoragePojo.setNumberOfViews(0L);
		}
		imgStoragePojo.setNumberOfViews(imgStoragePojo.getNumberOfViews() + 1);
		imgStorageRepository.save(imgStoragePojo);
	}

	public List<ImgStoragePojo> findFirst20ByOrderByNumberOfViewsDesc() {
		return imgStorageRepository.findFirst20ByOrderByNumberOfViewsDesc();
	}

	public List<ImgStoragePojo> findFirst20ByOrderByNumberOfCommentsDesc() {
		return imgStorageRepository.findFirst20ByOrderByNumberOfCommentsDesc();
	}

	public Integer countImgStoragePojo() {
		Long longNumber = imgStorageRepository.count();
		Integer integerNumber = longNumber.intValue();
		return integerNumber;
	}

	public List<ImgStoragePojo> findByOrderByNumberOfCommentsDesc(PageRequest of) {
		return imgStorageRepository.findByOrderByNumberOfCommentsDesc(of);
	}

	public List<ImgStoragePojo> findByOrderByNumberOfViewsDesc(PageRequest of) {
		return imgStorageRepository.findByOrderByNumberOfViewsDesc(of);
	}

	public List<ImgStoragePojo> findFirst20ByGroupsPojoGroupIDOrderByNumberOfViewsDesc(Long groupID) {
		return imgStorageRepository.findFirst20ByGroupsPojoGroupIDOrderByNumberOfViewsDesc(groupID);
	}

	public List<ImgStoragePojo> findFirst20ByGroupsPojoGroupIDOrderByNumberOfCommentsDesc(Long groupID) {
		return imgStorageRepository.findFirst20ByGroupsPojoGroupIDOrderByNumberOfCommentsDesc(groupID);
	}

	public List<ImgStoragePojo> findFirst20ByGroupsPojoGroupIDAndTopicTypeOrderByImgStorageIDDesc(Long groupID, String string) {
		return imgStorageRepository.findFirst20ByGroupsPojoGroupIDAndTopicTypeOrderByImgStorageIDDesc(groupID, string);
	}

}
