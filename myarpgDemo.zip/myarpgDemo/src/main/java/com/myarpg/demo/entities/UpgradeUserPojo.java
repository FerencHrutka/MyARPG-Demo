package com.myarpg.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.joda.time.DateTime;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class UpgradeUserPojo {

	@Id
	@GeneratedValue
	private Long upgradeUserID;
	private String name;
	private Long userID;

	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm")
	private DateTime lifeTime;

	public UpgradeUserPojo() {
	}

	public Long getUpgradeUserID() {
		return upgradeUserID;
	}

	public void setUpgradeUserID(Long upgradeUserID) {
		this.upgradeUserID = upgradeUserID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getUserID() {
		return userID;
	}

	public void setUserID(Long userID) {
		this.userID = userID;
	}

	public DateTime getLifeTime() {
		return lifeTime;
	}

	public void setLifeTime(DateTime lifeTime) {
		this.lifeTime = lifeTime;
	}

}
