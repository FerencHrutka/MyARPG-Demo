package com.myarpg.demo.service;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.myarpg.demo.entities.Role;
import com.myarpg.demo.entities.UsersPojo;

public class UsersLogin implements UserDetails {
	private static final long serialVersionUID = 123456L;

	UtilsService utilsService;

	@Autowired
	public void setUtilsService(UtilsService utilsService) {
		this.utilsService = utilsService;
	}

	private UsersPojo usersPojo;

	public UsersLogin(UsersPojo usersPojo) {
		this.usersPojo = usersPojo;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {

		Collection<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();

		Set<Role> roles = usersPojo.getRole();
		for (Role role : roles) {

			authorities.add(new SimpleGrantedAuthority(role.getRole()));
		}

		return authorities;
	}

	@Override
	public String getPassword() {
		return usersPojo.getUserPassword();
	}

	@Override
	public String getUsername() {
		return usersPojo.getUserEmail();
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return usersPojo.getUserEnabled();
	}

}