package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.GroupsPojo;

public interface GroupsRepository extends CrudRepository<GroupsPojo, Long> {

	List<GroupsPojo> findAllByOrderByCreatingTimeDesc();

	GroupsPojo findByUrl(String groupUrlName);

	GroupsPojo findByname(String groupName);

	GroupsPojo findBygroupID(long groupID);

	List<GroupsPojo> findByGroupIDNot(long l, Pageable pageable);

	Integer countByNameIsContainingIgnoreCase(String name);

	List<GroupsPojo> findByNameIsContainingIgnoreCase(String name, Pageable pageable);
}
