package com.myarpg.demo.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myarpg.demo.entities.AccessPojo;
import com.myarpg.demo.entities.GroupsPojo;
import com.myarpg.demo.entities.UsersPojo;
import com.myarpg.demo.repository.AccessRepository;
import com.myarpg.demo.repository.UsersRepository;

@Service
public class AccessService {

	AccessRepository accessRepository;

	@Autowired
	public void setAccessRepository(AccessRepository accessRepository) {
		this.accessRepository = accessRepository;
	}

	UsersRepository usersRepository;

	@Autowired
	public void setUsersRepository(UsersRepository usersRepository) {
		this.usersRepository = usersRepository;
	}

	UsersService usersService;

	@Autowired
	public void setUsersService(UsersService usersService) {
		this.usersService = usersService;
	}

	public AccessPojo setLoggedUserAccessPojo(UsersPojo loggedUser, GroupsPojo selectedGroup) {

		AccessPojo userPermissionAccessPojo = new AccessPojo();
		// ... MyARPG.com sesitive information
		return userPermissionAccessPojo;
	}

	public AccessPojo newUserClass(UsersPojo loggedUser, GroupsPojo selectedGroup, AccessPojo thymeleafAccessPojo) {
		AccessPojo checkAccessPojoName = null;
		try {
			checkAccessPojoName = accessRepository.findByGroupIDAndName(selectedGroup.getGroupID(), thymeleafAccessPojo.getName());
		} catch (Exception e) {
		}
		if (checkAccessPojoName == null) {
			AccessPojo newAccessPojo = new AccessPojo();
			newAccessPojo.setName(thymeleafAccessPojo.getName());
			newAccessPojo.setDescription(thymeleafAccessPojo.getDescription());
			newAccessPojo.setGroupID(selectedGroup.getGroupID());
			accessRepository.save(newAccessPojo);
		}
		return null;
	}

	public AccessPojo findByAccessID(long accessID) {
		return accessRepository.findByaccessID(accessID);
	}

	public AccessPojo editUserClassNameAndDesc(AccessPojo thymeleafAccessPojo) {
		AccessPojo selectedAccessPojo = null;
		try {
			selectedAccessPojo = accessRepository.findByaccessID(thymeleafAccessPojo.getAccessID());
		} catch (Exception e) {
		}
		if (selectedAccessPojo != null) {
			selectedAccessPojo.setName(thymeleafAccessPojo.getName());
			selectedAccessPojo.setDescription(thymeleafAccessPojo.getDescription());
			accessRepository.save(selectedAccessPojo);
		}
		return null;
	}

	public void joinClass(UsersPojo loggedUser, AccessPojo thymeleafAccessPojo) {
		boolean sendToDatabase = true;
		for (int i = 0; i < loggedUser.getAccessPojoList().size(); i++) {
			AccessPojo checkAccessPojo = loggedUser.getAccessPojoList().get(i);
			if (checkAccessPojo.getAccessID() == thymeleafAccessPojo.getAccessID()) {
				sendToDatabase = false;
			}
		}

		if (sendToDatabase) {
			usersRepository.InsertUserAndAccessToUsersAccess(loggedUser.getUserID(), thymeleafAccessPojo.getAccessID());
		}

	}

	public void joinClassLobby(UsersPojo loggedUser, AccessPojo thymeleafAccessPojo) {
		boolean sendToDatabase = true;
		for (int i = 0; i < loggedUser.getAccessPojoList().size(); i++) {
			AccessPojo checkAccessPojo = loggedUser.getAccessPojoList().get(i);
			if (checkAccessPojo.getAccessID() == thymeleafAccessPojo.getAccessID()) {
				sendToDatabase = false;
			}
		}

		if (sendToDatabase) {
			usersRepository.InsertUserAndAccessToUsersAccessLobby(loggedUser.getUserID(), thymeleafAccessPojo.getAccessID());
		}
	}

	public List<AccessPojo> getAccessPojoList(GroupsPojo selectedGroup) {
		return accessRepository.findByGroupIDOrderByAccessID(selectedGroup.getGroupID());
	}

	public List<UsersPojo> getMembersUsersPojoListByAccessPojoListInThisGroup(GroupsPojo selectedGroup) {

		List<AccessPojo> accessPojoList = accessRepository.findByGroupIDOrderByAccessID(selectedGroup.getGroupID());

		List<UsersPojo> usersPojoList = new ArrayList<UsersPojo>();

		for (int i = 0; i < accessPojoList.size(); i++) {
			for (int j = 0; j < accessPojoList.get(i).getUsersPojoList().size(); j++) {
				usersPojoList.add(accessPojoList.get(i).getUsersPojoList().get(j));
			}
		}

		List<UsersPojo> cleanUsersPojoList = usersPojoList.stream().distinct().collect(Collectors.toList());

		cleanUsersPojoList.sort(Comparator.comparing(UsersPojo::getUserName));

		return cleanUsersPojoList;
	}

	public List<UsersPojo> getGroupMembersAndAllEnabledUser(GroupsPojo selectedGroup) {
		List<UsersPojo> membersUsersPojoList = getMembersUsersPojoListByAccessPojoListInThisGroup(selectedGroup);

		List<UsersPojo> usersPojoList = usersService.findByUserEnabledTrueOrderByUserNameAsc();

		for (int i = 0; i < membersUsersPojoList.size(); i++) {
			for (int j = 0; j < usersPojoList.size(); j++) {
				if (membersUsersPojoList.get(i).getUserID().equals(usersPojoList.get(j).getUserID())) {
					usersPojoList.remove(j);
				}
			}
		}

		membersUsersPojoList.addAll(usersPojoList);
		return membersUsersPojoList;
	}

}
