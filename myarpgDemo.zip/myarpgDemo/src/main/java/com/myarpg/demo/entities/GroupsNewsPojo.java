package com.myarpg.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class GroupsNewsPojo {

	@GeneratedValue
	@Id
	private Long groupsNewsID;

	@ManyToOne(cascade = CascadeType.ALL)
	private GroupsHomePojo groupsHomePojo;
	private Long groupID;

	@Column(length=4000)
	private String newsText;
	private String newsTitle;
	private String newsAuthor;
	private String newsPostedTime;
	private Integer number;

	public GroupsNewsPojo() {
	}

	public Long getGroupsNewsID() {
		return groupsNewsID;
	}

	public void setGroupsNewsID(Long groupsNewsID) {
		this.groupsNewsID = groupsNewsID;
	}

	public GroupsHomePojo getGroupsHomePojo() {
		return groupsHomePojo;
	}

	public void setGroupsHomePojo(GroupsHomePojo groupsHomePojo) {
		this.groupsHomePojo = groupsHomePojo;
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	public String getNewsText() {
		return newsText;
	}

	public void setNewsText(String newsText) {
		this.newsText = newsText;
	}

	public String getNewsTitle() {
		return newsTitle;
	}

	public void setNewsTitle(String newsTitle) {
		this.newsTitle = newsTitle;
	}

	public String getNewsAuthor() {
		return newsAuthor;
	}

	public void setNewsAuthor(String newsAuthor) {
		this.newsAuthor = newsAuthor;
	}

	public String getNewsPostedTime() {
		return newsPostedTime;
	}

	public void setNewsPostedTime(String newsPostedTime) {
		this.newsPostedTime = newsPostedTime;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

}
