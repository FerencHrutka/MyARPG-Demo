package com.myarpg.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.joda.time.DateTime;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class CommentPojo {

	@GeneratedValue
	@Id
	private Long commentID;
	private Long imgStorageID;

	@ManyToOne(cascade = CascadeType.ALL)
	private ImgStoragePojo imgStoragePojo;

	@ManyToOne(cascade = CascadeType.ALL)
	private GroupsPojo groupsPojo;

	@ManyToOne(cascade = CascadeType.ALL)
	private UsersPojo usersPojo;

	@Column(length=4000)
	private String comment;
	
	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm")
	private DateTime postedTime;	
	private Long reply;
	private String replyUserName;
	private Integer marginLeft;
	private Integer position;
	private Boolean hide;
	private Boolean deleted;
	

	public CommentPojo() {
	}

	public Long getCommentID() {
		return commentID;
	}

	public void setCommentID(Long commentID) {
		this.commentID = commentID;
	}

	public ImgStoragePojo getImgStoragePojo() {
		return imgStoragePojo;
	}

	public void setImgStoragePojo(ImgStoragePojo imgStoragePojo) {
		this.imgStoragePojo = imgStoragePojo;
	}

	public GroupsPojo getGroupsPojo() {
		return groupsPojo;
	}

	public void setGroupsPojo(GroupsPojo groupsPojo) {
		this.groupsPojo = groupsPojo;
	}

	public UsersPojo getUsersPojo() {
		return usersPojo;
	}

	public void setUsersPojo(UsersPojo usersPojo) {
		this.usersPojo = usersPojo;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Long getImgStorageID() {
		return imgStorageID;
	}

	public void setImgStorageID(Long imgStorageID) {
		this.imgStorageID = imgStorageID;
	}

	public DateTime getPostedTime() {
		return postedTime;
	}

	public void setPostedTime(DateTime postedTime) {
		this.postedTime = postedTime;
	}

	public Integer getMarginLeft() {
		return marginLeft;
	}

	public void setMarginLeft(Integer marginLeft) {
		this.marginLeft = marginLeft;
	}

	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	public Long getReply() {
		return reply;
	}

	public void setReply(Long reply) {
		this.reply = reply;
	}

	public String getReplyUserName() {
		return replyUserName;
	}

	public void setReplyUserName(String replyUserName) {
		this.replyUserName = replyUserName;
	}

	public Boolean getHide() {
		return hide;
	}

	public void setHide(Boolean hide) {
		this.hide = hide;
	}

	public Boolean getDeleted() {
		return deleted;
	}

	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}

	
	

}
