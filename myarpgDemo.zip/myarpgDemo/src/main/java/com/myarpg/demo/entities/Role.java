package com.myarpg.demo.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Role {

	@Id
	@GeneratedValue
	private Long roleID;
	private String role;

	@ManyToMany(mappedBy = "role")
	private Set<UsersPojo> usersPojo = new HashSet<UsersPojo>();

	@OneToOne(mappedBy = "role", cascade = CascadeType.ALL)
	@JoinColumn
	private AccessPojo accessPojo;

	private Long groupID;

	public Role() {
	}

	public Role(String role) {
		this.role = role;
	}

	public Long getRoleID() {
		return roleID;
	}

	public void setRoleID(Long roleID) {
		this.roleID = roleID;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Set<UsersPojo> getUsersPojo() {
		return usersPojo;
	}

	public void setUsersPojo(Set<UsersPojo> usersPojo) {
		this.usersPojo = usersPojo;
	}

	public AccessPojo getAccessPojo() {
		return accessPojo;
	}

	public void setAccessPojo(AccessPojo accessPojo) {
		this.accessPojo = accessPojo;
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	@Override
	public String toString() {
		return "Role [role=" + role + "]";
	}

}