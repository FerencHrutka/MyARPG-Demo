package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.WarningPojo;

public interface WarningRepository extends CrudRepository<WarningPojo, Long> {

	List<WarningPojo> findAllByOrderByWarningIDDesc();
	
}
