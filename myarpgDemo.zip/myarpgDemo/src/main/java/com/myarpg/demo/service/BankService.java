package com.myarpg.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myarpg.demo.entities.BankPojo;
import com.myarpg.demo.entities.GroupsPojo;
import com.myarpg.demo.entities.UsersPojo;
import com.myarpg.demo.repository.BankRepository;

@Service
public class BankService {

	BankRepository bankRepository;

	@Autowired
	public void setBankRepository(BankRepository bankRepository) {
		this.bankRepository = bankRepository;
	}

	UsersService usersService;

	@Autowired
	public void setUsersService(UsersService usersService) {
		this.usersService = usersService;
	}

	public BankPojo findByUserIDAndItemsPojoItemID(Long userID, Long itemID) {
		BankPojo selectedBankPojo = null;
		try {
			selectedBankPojo = bankRepository.findByUserIDAndItemsPojoItemID(userID, itemID);
		} catch (Exception e) {
		}

		if (selectedBankPojo == null) {
			return null;
		}
		return selectedBankPojo;
	}

	public List<BankPojo> getNewItemsSelectAsChangedAndSetUnchanged(UsersPojo loggedUser, GroupsPojo selectedGroup) {
		List<BankPojo> selectedBankPojoList = new ArrayList<BankPojo>();

		for (int i = 0; i < loggedUser.getBankPojo().size(); i++) {

			if (loggedUser.getBankPojo().get(i).getGroupID().equals(selectedGroup.getGroupID())
					&& loggedUser.getBankPojo().get(i).isChanged()) {
				BankPojo bankPojo = new BankPojo();
				bankPojo.setCloneBankPojo(loggedUser.getBankPojo().get(i));
				selectedBankPojoList.add(bankPojo);

				loggedUser.getBankPojo().get(i).setChanged(false);
				loggedUser.getBankPojo().get(i).setChangedQuantity(0L);
				loggedUser.getBankPojo().get(i).setNewBankItem(false);
				usersService.saveThisUser(loggedUser);
			}
		}
		return selectedBankPojoList;
	}

}
