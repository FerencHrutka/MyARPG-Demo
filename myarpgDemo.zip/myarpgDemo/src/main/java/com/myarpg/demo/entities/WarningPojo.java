package com.myarpg.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.joda.time.DateTime;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class WarningPojo {

	@GeneratedValue
	@Id
	private Long warningID;
	private String message;
	private String backgroundColor;
	private String fontColor;

	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm")
	@Column(name = "endTime")
	private DateTime end;

	public WarningPojo() {
	}

	public Long getWarningID() {
		return warningID;
	}

	public void setWarningID(Long warningID) {
		this.warningID = warningID;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getBackgroundColor() {
		return backgroundColor;
	}

	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}

	public String getFontColor() {
		return fontColor;
	}

	public void setFontColor(String fontColor) {
		this.fontColor = fontColor;
	}

	public DateTime getEnd() {
		return end;
	}

	public void setEnd(DateTime end) {
		this.end = end;
	}

}
