package com.myarpg.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class UpgradePojo {

	@Id
	@GeneratedValue
	private Long upgradeID;
	private String name;
	private String type;
	private String url;
	private Integer price;
	private Integer coin;
	private Integer lifetime;

	public UpgradePojo() {
	}

	public Long getUpgradeID() {
		return upgradeID;
	}

	public void setUpgradeID(Long upgradeID) {
		this.upgradeID = upgradeID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getPrice() {
		return price;
	}

	public void setPrice(Integer price) {
		this.price = price;
	}

	public Integer getLifetime() {
		return lifetime;
	}

	public void setLifetime(Integer lifetime) {
		this.lifetime = lifetime;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Integer getCoin() {
		return coin;
	}

	public void setCoin(Integer coin) {
		this.coin = coin;
	}

}
