package com.myarpg.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class CharacterPropertiesPojo {

	@GeneratedValue
	@Id
	private Long characterPropertiesID;
	private Long characterID;
	private String name;
	private String value;
	private Integer position;

	public CharacterPropertiesPojo() {
	}

	public Long getCharacterPropertiesID() {
		return characterPropertiesID;
	}

	public void setCharacterPropertiesID(Long characterPropertiesID) {
		this.characterPropertiesID = characterPropertiesID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	public Long getCharacterID() {
		return characterID;
	}

	public void setCharacterID(Long characterID) {
		this.characterID = characterID;
	}

}
