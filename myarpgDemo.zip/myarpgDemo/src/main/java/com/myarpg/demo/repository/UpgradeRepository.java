package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.UpgradePojo;

public interface UpgradeRepository extends CrudRepository<UpgradePojo, Long> {

	List<UpgradePojo> findAll();

	List<UpgradePojo> findByType(String string);

	UpgradePojo findByUpgradeID(Long upgradeID);
}
