package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.myarpg.demo.entities.SpeciesPojo;

public interface SpeciesRepository extends CrudRepository<SpeciesPojo, Long> {

	List<SpeciesPojo> findAll();

	SpeciesPojo findByName(String valami);

	List<SpeciesPojo> findByGroupID(Long groupID, Pageable pageable);

	List<SpeciesPojo> findByGroupIDAndUrl(Long groupID, String selectedSpeciesUrl);

	List<SpeciesPojo> findByGroupIDAndSubSpeciesIDOrderBySpeciesID(Long groupID, long l, Pageable pageable);

	List<SpeciesPojo> findByGroupIDAndSubSpeciesIDOrderBySpeciesID(Long groupID, long l);

	SpeciesPojo findBySpeciesID(Long speciesID);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM species_pojo WHERE speciesid = :speciesID ;", nativeQuery = true)
	public void deleteBySpeciesID(@Param("speciesID") Long speciesID);

	List<SpeciesPojo> findBySubSpeciesID(Long subSpeciesID);

	Integer countByGroupID(Long groupID);

	Integer countByGroupIDAndSubSpeciesIDOrderBySpeciesID(Long groupID, long l);

	List<SpeciesPojo> findByGroupID(Long groupID);
}
