package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.myarpg.demo.entities.GroupsHomePojo;

public interface GroupsHomeRepository extends CrudRepository<GroupsHomePojo, Long> {

	List<GroupsHomePojo> findByGroupsHomeID(Long GroupsHomeID);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM groups_home_pojo WHERE groupid = :groupID AND position = :position ;", nativeQuery = true)
	public void deleteByGroupsIDAndPosition(@Param("groupID") Long groupID, @Param("position") Integer position);

}


