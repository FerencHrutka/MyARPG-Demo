package com.myarpg.demo.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;

import org.joda.time.DateTime;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class EventPojo {

	@GeneratedValue
	@Id
	private Long eventID;
	private Long groupID;
	private String title;

	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm")
	@Column(name = "startTime")
	private DateTime start;

	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm")
	@Column(name = "endTime")
	private DateTime end;
	private String color;
	private String url;
	private String rendering;
	private String creator;
	private String lastEditedBy;
	private String category;
	private String type;
	private String submissionType;
	private String winner;
	private String participantLimit;
	private String repeatable;
	private String prerequisite;
	private String accesPojoList;

	@Column(length = 2500)
	private String itemRewardListJSON;
	private boolean onlyOnceOption;
	private Long minItemDrop;
	private Long maxItemDrop;
	private Long number;
	private boolean rewardListHide;

	@OneToOne(cascade = CascadeType.ALL)
	private ImgStoragePojo ImgStoragePojo;

	@OneToMany(cascade = CascadeType.ALL)
	@OrderBy("eventID ASC")
	@JoinColumn(name = "eventID", referencedColumnName = "eventID")
	private List<EventParticipantPojo> eventParticipantPojo;
	private String status;

	public EventPojo() {
	}

	public Long getEventID() {
		return eventID;
	}

	public void setEventID(Long eventID) {
		this.eventID = eventID;
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public DateTime getStart() {
		return start;
	}

	public void setStart(DateTime start) {
		this.start = start;
	}

	public DateTime getEnd() {
		return end;
	}

	public void setEnd(DateTime end) {
		this.end = end;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getRendering() {
		return rendering;
	}

	public void setRendering(String rendering) {
		this.rendering = rendering;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getLastEditedBy() {
		return lastEditedBy;
	}

	public void setLastEditedBy(String lastEditedBy) {
		this.lastEditedBy = lastEditedBy;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSubmissionType() {
		return submissionType;
	}

	public void setSubmissionType(String submissionType) {
		this.submissionType = submissionType;
	}

	public String getWinner() {
		return winner;
	}

	public void setWinner(String winner) {
		this.winner = winner;
	}

	public String getParticipantLimit() {
		return participantLimit;
	}

	public void setParticipantLimit(String participantLimit) {
		this.participantLimit = participantLimit;
	}

	public String getRepeatable() {
		return repeatable;
	}

	public void setRepeatable(String repeatable) {
		this.repeatable = repeatable;
	}

	public String getPrerequisite() {
		return prerequisite;
	}

	public void setPrerequisite(String prerequisite) {
		this.prerequisite = prerequisite;
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}

	public String getAccesPojoList() {
		return accesPojoList;
	}

	public void setAccesPojoList(String accesPojoList) {
		this.accesPojoList = accesPojoList;
	}

	public String getItemRewardListJSON() {
		return itemRewardListJSON;
	}

	public void setItemRewardListJSON(String itemRewardListJSON) {
		this.itemRewardListJSON = itemRewardListJSON;
	}

	public boolean isOnlyOnceOption() {
		return onlyOnceOption;
	}

	public void setOnlyOnceOption(boolean onlyOnceOption) {
		this.onlyOnceOption = onlyOnceOption;
	}

	public Long getMinItemDrop() {
		return minItemDrop;
	}

	public void setMinItemDrop(Long minItemDrop) {
		this.minItemDrop = minItemDrop;
	}

	public Long getMaxItemDrop() {
		return maxItemDrop;
	}

	public void setMaxItemDrop(Long maxItemDrop) {
		this.maxItemDrop = maxItemDrop;
	}

	public boolean isRewardListHide() {
		return rewardListHide;
	}

	public void setRewardListHide(boolean rewardListHide) {
		this.rewardListHide = rewardListHide;
	}

	public ImgStoragePojo getImgStoragePojo() {
		return ImgStoragePojo;
	}

	public void setImgStoragePojo(ImgStoragePojo imgStoragePojo) {
		ImgStoragePojo = imgStoragePojo;
	}

	public List<EventParticipantPojo> getEventParticipantPojo() {
		return eventParticipantPojo;
	}

	public void setEventParticipantPojo(List<EventParticipantPojo> eventParticipantPojo) {
		this.eventParticipantPojo = eventParticipantPojo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String toJson() {
		return "{'title':'" + title + " (" + type + ") " + "', 'start':'" + start + "', 'end':'" + end + "', 'color':'" + color
				+ "', 'url':'" + url + "'}";
	}
}
