package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.ImgCategoryPojo;

public interface ImgCategoryRepository extends CrudRepository<ImgCategoryPojo, Long> {
	
	List<ImgCategoryPojo> findAll();
	
	List<ImgCategoryPojo> findByGroupID(Long groupID);
	
	ImgCategoryPojo findByImgCategoryID(Long imgCategoryID);

}
