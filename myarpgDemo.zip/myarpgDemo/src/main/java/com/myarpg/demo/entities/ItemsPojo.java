package com.myarpg.demo.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;

@Entity
public class ItemsPojo {

	@GeneratedValue
	@Id
	private Long itemID;
	private Long groupID;
	private String name;
	private Long number;
	private Long itemCategoriesID;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "itemID", nullable = true)
	@OrderBy("position ASC")
	private List<ItemPropertiesPojo> itemPropertiesPojo;

	@OneToOne
	private ImgStoragePojo imgStoragePojo;

	public ItemsPojo() {
	}

	public Long getItemID() {
		return itemID;
	}

	public void setItemID(Long itemID) {
		this.itemID = itemID;
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getItemCategoriesID() {
		return itemCategoriesID;
	}

	public void setItemCategoriesID(Long itemCategoriesID) {
		this.itemCategoriesID = itemCategoriesID;
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}

	public List<ItemPropertiesPojo> getItemPropertiesPojo() {
		return itemPropertiesPojo;
	}

	public void setItemPropertiesPojo(List<ItemPropertiesPojo> itemPropertiesPojo) {
		this.itemPropertiesPojo = itemPropertiesPojo;
	}

	public ImgStoragePojo getImgStoragePojo() {
		return imgStoragePojo;
	}

	public void setImgStoragePojo(ImgStoragePojo imgStoragePojo) {
		this.imgStoragePojo = imgStoragePojo;
	}

}
