package com.myarpg.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class ImgCategoryPojo {

	@Id
	@GeneratedValue
	private Long imgCategoryID;

	private String Name;
	private String Path;
	private String Type;
	
	@Column(length=4000)
	private String Description;

	private boolean Allowed;

	private String SpringAdvSec5Type;
	private Long groupID;
	private Long userID;

	public ImgCategoryPojo() {
	}

	public Long getImgCategoryID() {
		return imgCategoryID;
	}

	public void setImgCategoryID(Long imgCategoryID) {
		this.imgCategoryID = imgCategoryID;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getPath() {
		return Path;
	}

	public void setPath(String path) {
		Path = path;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public boolean isAllowed() {
		return Allowed;
	}

	public void setAllowed(boolean allowed) {
		Allowed = allowed;
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	public Long getUserID() {
		return userID;
	}

	public void setUserID(Long userID) {
		this.userID = userID;
	}

	public String getSpringAdvSec5Type() {
		return SpringAdvSec5Type;
	}

	public void setSpringAdvSec5Type(String springAdvSec5Type) {
		SpringAdvSec5Type = springAdvSec5Type;
	}

	
}
