package com.myarpg.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class ItemPropertiesPojo {

	@GeneratedValue
	@Id
	private Long itemPropertiesID;
	private Long itemID;
	private String name;
	private String value;
	private Integer position;

	public ItemPropertiesPojo() {
	}

	public Long getItemPropertiesID() {
		return itemPropertiesID;
	}

	public void setItemPropertiesID(Long itemPropertiesID) {
		this.itemPropertiesID = itemPropertiesID;
	}

	public Long getItemID() {
		return itemID;
	}

	public void setItemID(Long itemID) {
		this.itemID = itemID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

}
