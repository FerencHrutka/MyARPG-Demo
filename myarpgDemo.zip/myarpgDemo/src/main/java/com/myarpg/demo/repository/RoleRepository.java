package com.myarpg.demo.repository;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.Role;

public interface RoleRepository extends CrudRepository<Role, Long>  {
	
	Role findByRole(String role);

}
