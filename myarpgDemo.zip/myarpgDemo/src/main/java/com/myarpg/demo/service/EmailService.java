package com.myarpg.demo.service;

import java.nio.charset.StandardCharsets;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

	@Value("${spring.mail.host}")
	private String MAIL_HOST;

	@Value("${spring.mail.username}")
	private String MESSAGE_FROM;

	@Value("${spring.mail.password}")
	private String MAIL_PASSWORD;

	@Value("${spring.mail.port}")
	private String MAIL_SSL_PORT;

	@Value("${spring.mail.properties.mail.smtp.socketFactory.port}")
	private String MAIL_TLS_PORT;

	@Value("${spring.mail.properties.mail.smtp.auth}")
	private Boolean SMTP_AUTH;

	@Value("${spring.mail.properties.mail.smtp.starttls.enable}")
	private Boolean STARTSSL_ENABLE;

	public void setJavaMailSender(JavaMailSender javaMailSender) {
	}

	String activationLink = "www.myarpg.com/activation/qAs8745RVC";

	public void sendRegistrationMessage(String userEmail, String userFirstName, String userActivationKey) {
		String to = userEmail;

		String from = MESSAGE_FROM;
		final String username = MESSAGE_FROM;
		final String password = MAIL_PASSWORD;

		String host = MAIL_HOST;

		Properties props = new Properties();
		props.put("mail.smtp.auth", SMTP_AUTH);
		props.put("mail.smtp.starttls.enable", STARTSSL_ENABLE);
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", MAIL_SSL_PORT);

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			message.setSubject("Welcome to myarpg.com");

			MimeMessageHelper helper = new MimeMessageHelper((MimeMessage) message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			String text = "<p style=\"text-align: center;\"><img src=\"https://www.myarpg.com/img/default/logo/logo_tiny.png\"></p><p style=\"text-align: center;\">Hi&nbsp; "
					+ userFirstName
					+ "!</p><p style=\"text-align: center;\">Greetings from myarpg.com!&nbsp;<br>Thank you for signing up to our website!<br>Please verify your email address in order to use your account.<br>Here is your activation link:<br><a href=\"https://www.myarpg.com/activation/"
					+ userActivationKey + "\" target=\"_blank\">https://www.myarpg.com/activation/" + userActivationKey
					+ "</a><br>Please click the link or paste it to your browser.<br>Best regards, Team myarpg.com<br><br></p>";

			helper.setText(text, true);
			Transport.send(message);

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

	public void sendPasswordRecovery(String userEmail, String userpasswordRecoveryKey) {
		String to = userEmail;

		String from = MESSAGE_FROM;
		final String username = MESSAGE_FROM;
		final String password = MAIL_PASSWORD;

		String host = MAIL_HOST;

		Properties props = new Properties();
		props.put("mail.smtp.auth", SMTP_AUTH);
		props.put("mail.smtp.starttls.enable", STARTSSL_ENABLE);
		props.put("mail.smtp.host", host);
		props.put("mail.smtp.port", MAIL_SSL_PORT);

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {
			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
			message.setSubject("Password recovery");

			MimeMessageHelper helper = new MimeMessageHelper((MimeMessage) message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			String text = "<p style=\"text-align: center;\"><img src=\"https://www.myarpg.com/img/default/logo/logo_tiny.png\"></p><p style=\"text-align: center;\"><span style=\"font-size: 1rem;\">Greetings,&nbsp;</span><br></p><p style=\"text-align: center;\">You're receiving this email because you requested a password reset for your myarpg.com account.<br>If you did not request this change, you can safely ignore this email.<br>To choose a new password and complete your request, please follow the link below:<br><a href=\"https://www.myarpg.com/passwordRecoveryStep3\" target=\"_blank\">https://www.myarpg.com/passwordRecoveryStep3</a><br>Your recovery code: "
					+ userpasswordRecoveryKey
					+ "<br><span style=\"color: rgb(52, 58, 64);\">Please click the link or paste it to your browser.</span><br style=\"color: rgb(52, 58, 64);\"><span style=\"color: rgb(52, 58, 64);\">Best regards, Team myarpg.com</span><br></p>";

			helper.setText(text, true);
			Transport.send(message);

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}
}
