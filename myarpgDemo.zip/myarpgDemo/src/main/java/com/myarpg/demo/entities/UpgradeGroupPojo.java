package com.myarpg.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.joda.time.DateTime;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class UpgradeGroupPojo {

	@Id
	@GeneratedValue
	private Long UpgradeGroupID;
	private String name;
	private Long groupID;

	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm")
	private DateTime lifeTime;

	public UpgradeGroupPojo() {
	}

	public Long getUpgradeGroupID() {
		return UpgradeGroupID;
	}

	public void setUpgradeGroupID(Long upgradeGroupID) {
		UpgradeGroupID = upgradeGroupID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	public DateTime getLifeTime() {
		return lifeTime;
	}

	public void setLifeTime(DateTime lifeTime) {
		this.lifeTime = lifeTime;
	}

}
