package com.myarpg.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myarpg.demo.entities.UpgradePojo;
import com.myarpg.demo.repository.UpgradeRepository;

@Service
public class UpgradeService {

	UpgradeRepository upgradeRepository;

	@Autowired
	public void setUpgradeRepository(UpgradeRepository upgradeRepository) {
		this.upgradeRepository = upgradeRepository;
	}

	public static UpgradePojo setUpgradeByPaymentDescription(String description) {
		UpgradePojo selectedUpgradePojo = null;
		// ... MyARPG.com sesitive information
		return selectedUpgradePojo;

	}

	public UpgradePojo getUpgradePojo(String description) {
		String upgradeIDString = description.substring(description.indexOf(":") + 1, description.indexOf(";"));
		description.substring(description.indexOf(";") + 1);
		UpgradePojo selectedUpgradePojo = null;
		try {
			selectedUpgradePojo = upgradeRepository.findByUpgradeID(Long.parseLong(upgradeIDString));
		} catch (Exception e) {
		}

		if (selectedUpgradePojo == null) {
			return null;
		}
		return selectedUpgradePojo;
	}

}
