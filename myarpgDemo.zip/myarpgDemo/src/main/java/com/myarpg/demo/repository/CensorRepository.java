package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.CensorPojo;

public interface CensorRepository extends CrudRepository<CensorPojo, Long> {

	List<CensorPojo> findAll();

	CensorPojo findByBannedWordsForUsername(String bannedWordsForUsername);

}
