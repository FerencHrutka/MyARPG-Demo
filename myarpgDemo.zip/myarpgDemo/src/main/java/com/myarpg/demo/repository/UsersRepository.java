package com.myarpg.demo.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.myarpg.demo.entities.UsersPojo;

public interface UsersRepository extends CrudRepository<UsersPojo, Long> {

	List<UsersPojo> findAll();
	
	List<UsersPojo> findByUserEnabledTrueOrderByUserNameAsc();
	
	UsersPojo findByuserEmailIgnoreCase(String email);
	
	UsersPojo findByuserActivationKey(String key);
	
	UsersPojo findByuserNameIgnoreCase(String userName);
	
	@Query(value = "SELECT users_pojo_userid FROM users_roles WHERE users_pojo_userid = :userId AND role_roleid= :roleId", nativeQuery=true )	
	List<Long> findByUserIdWhereSelectedUserIdAndSelectedRoleIdIsEqual(@Param("userId") Long userId, @Param("roleId") Long roleId);

	@Modifying
    @Query(value = "INSERT INTO users_roles (users_pojo_userid, role_roleid) VALUES (:userID, :roleId) ;", nativeQuery = true)
	@Transactional
    void InsertUserAndRoleToUsersRoles(@Param("userID") Long userID, @Param("roleId") Long roleId);

	@Modifying
    @Query(value = "DELETE FROM users_roles WHERE users_pojo_userid = :userID AND role_roleid = :roleId ;", nativeQuery = true)
	@Transactional
	void RemoveUserAndRoleToUsersRoles(@Param("userID") Long userID, @Param("roleId") Long roleId);

	UsersPojo findByUserID(Long userID);

	@Modifying
    @Query(value = "INSERT INTO users_access (users_pojo_userid, access_pojo_accessid) VALUES (:userID, :accessID) ;", nativeQuery = true)
	@Transactional
	void InsertUserAndAccessToUsersAccess(@Param("userID") Long userID, @Param("accessID") Long accessID);
	
	
	@Modifying
    @Query(value = "INSERT INTO users_access_lobby (users_pojo_userid, access_pojo_accessid) VALUES (:userID, :accessID) ;", nativeQuery = true)
	@Transactional
	void InsertUserAndAccessToUsersAccessLobby(Long userID, long accessID);
	
	@Modifying
    @Query(value = "DELETE FROM users_access_lobby WHERE users_pojo_userid = :userID AND access_pojo_accessid = :accessID ;", nativeQuery = true)
	@Transactional
	void DeleteUserInUsersAccessLobby(Long userID, long accessID);

	@Modifying
    @Query(value = "DELETE FROM users_access WHERE users_pojo_userid = :userID AND access_pojo_accessid = :accessID ;", nativeQuery = true)
	@Transactional
	void DeleteUserInUsersAccess(Long userID, long accessID);
	
	List<UsersPojo> findByUserIDNot(Long longNumber, Pageable pageable);

	Integer countByUserNameIsContainingIgnoreCase(String userName);

	List<UsersPojo> findByUserNameIsContainingIgnoreCase(String userName, Pageable pageable);

	@Query(value = "SELECT user_name FROM users_pojo;", nativeQuery = true)
	List<String> findAllUserName();

	@Modifying
    @Query(value = "INSERT INTO users_access_invite (users_pojo_userid, access_pojo_accessid) VALUES (:userID, :accessID) ;", nativeQuery = true)
	@Transactional
	void InsertUserAndAccessToUsersAccessInvite(Long userID, long accessID);
	
	@Modifying
    @Query(value = "DELETE FROM users_access_invite WHERE users_pojo_userid = :userID AND access_pojo_accessid = :accessID ;", nativeQuery = true)
	@Transactional
	void DeleteUserInUsersAccessInvite(Long userID, long accessID);
	
}





