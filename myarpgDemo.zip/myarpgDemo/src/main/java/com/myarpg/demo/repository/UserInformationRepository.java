package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.UserInformationPojo;

public interface UserInformationRepository extends CrudRepository<UserInformationPojo, Long> {

	List<UserInformationPojo> findAll();

}
