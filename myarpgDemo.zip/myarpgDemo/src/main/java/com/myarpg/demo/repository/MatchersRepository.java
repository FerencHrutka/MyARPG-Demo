package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.MatchersPojo;

public interface MatchersRepository extends CrudRepository<MatchersPojo, Long> {

	List<MatchersPojo> findAll();
}
