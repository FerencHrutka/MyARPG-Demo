package com.myarpg.demo.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.myarpg.demo.entities.MatchersPojo;
import com.myarpg.demo.service.UtilsService;

@EnableGlobalMethodSecurity(securedEnabled = true)
@Configuration
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	UtilsService utilsService;
	@Autowired
	public void setUtilsService(UtilsService utilsService) {
		this.utilsService = utilsService;
	}
	
	@Autowired
	private UserDetailsService userService;
	
	@Autowired
	public void configureAuth(AuthenticationManagerBuilder auth) throws Exception{
		auth.userDetailsService(userService).passwordEncoder(passwordEncoder());
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
			.authorizeRequests()
				.antMatchers("/groups").permitAll();
				
				// more .antMatchers in database
				List<MatchersPojo> matchers = utilsService.getMatchers();
				for (MatchersPojo matcher : matchers) {
			        http.authorizeRequests().antMatchers(matcher.url).hasRole(matcher.role);
			    }
				
				// http cache:
				http.headers().cacheControl().disable(); 
				
		http
			.authorizeRequests()		
			.and()
				.formLogin().loginPage("/login").permitAll()
			.and()
				.logout()
				.deleteCookies("JSESSIONID")
				.logoutUrl("/logout").permitAll()
				.logoutSuccessUrl("/?logout").permitAll()
				
			.and()
	            .rememberMe()
				.key("Secret_key_for_myarpgDemo").tokenValiditySeconds(1209600); // remeberMe cookie

		}	

	}	




