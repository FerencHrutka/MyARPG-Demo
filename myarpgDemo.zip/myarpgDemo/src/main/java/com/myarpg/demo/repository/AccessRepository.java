package com.myarpg.demo.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.myarpg.demo.entities.AccessPojo;

public interface AccessRepository extends CrudRepository<AccessPojo, Long>{

	List<AccessPojo> findByGroupIDOrderByAccessID(Long groupID);
	
	AccessPojo findByaccessID(Long accessID);
	
	AccessPojo findByNameAndGroupID(String name, Long groupID);
	
	@Query(value = "SELECT * FROM access_pojo WHERE role_roleid = :roleId ;", nativeQuery=true )	
	AccessPojo findByrole_roleid(@Param("roleId") Long roleId);

	AccessPojo findByGroupIDAndName(Long groupID, String name);

	@Modifying
    @Query(value = "DELETE FROM access_pojo WHERE accessid = :accessID ;", nativeQuery = true)
	@Transactional
	void deleteThisClass(Long accessID);
}
