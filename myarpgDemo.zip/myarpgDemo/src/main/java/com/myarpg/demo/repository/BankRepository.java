package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.BankPojo;

public interface BankRepository extends CrudRepository<BankPojo, Long> {

	List<BankPojo> findAll();

	BankPojo findByUserIDAndItemsPojoItemID(Long userID, Long itemID);

}
