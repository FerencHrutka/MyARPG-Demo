package com.myarpg.demo.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class AccessPojo {

	@Id
	@GeneratedValue
	private long accessID;

	@ManyToOne(cascade = CascadeType.ALL)
	private AccessPojo accessPojo;
	private Long groupID;
	private String name;
	private String description;

	@ManyToMany(mappedBy = "accessPojoList")
	private List<UsersPojo> usersPojoList = new ArrayList<UsersPojo>();

	@ManyToMany(mappedBy = "accessPojoLobbyList")
	private List<UsersPojo> usersPojoLobbyList = new ArrayList<UsersPojo>();

	@ManyToMany(mappedBy = "accessPojoInviteList")
	private List<UsersPojo> usersPojoInviteList = new ArrayList<UsersPojo>();

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "role_roleid")
	private Role role;

	private boolean admissionOpen;
	private boolean admissionAuto;
	private boolean groupHome;
	private boolean groupNews;
	private boolean groupEvents;
	private boolean groupGallery;
	private boolean groupMasterList;
	private boolean groupItems;
	private boolean groupMembers;
	private boolean groupGalleryUpload;
	private boolean groupGalleryDelete;
	private boolean groupEventEdit;
	private boolean groupEventModerating;
	private boolean groupAdminRead;
	private boolean groupAdminEdit;
	private boolean groupNewsEdit;
	private boolean groupMasterlistEdit;
	private boolean groupItemsEdit;
	private boolean groupMembersEdit;
	private boolean groupAccessRightsEdit;
	private boolean groupUpgradesEdit;
	private boolean groupHomeListEdit;
	private boolean groupComment;
	private boolean groupCommentHide;
	private boolean groupLogs;

	public AccessPojo() {
	}

	public long getAccessID() {
		return accessID;
	}

	public void setAccessID(long accessID) {
		this.accessID = accessID;
	}

	public AccessPojo getAccessPojo() {
		return accessPojo;
	}

	public void setAccessPojo(AccessPojo accessPojo) {
		this.accessPojo = accessPojo;
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isGroupHome() {
		return groupHome;
	}

	public void setGroupHome(boolean groupHome) {
		this.groupHome = groupHome;
	}

	public boolean isGroupNews() {
		return groupNews;
	}

	public void setGroupNews(boolean groupNews) {
		this.groupNews = groupNews;
	}

	public boolean isGroupEvents() {
		return groupEvents;
	}

	public void setGroupEvents(boolean groupEvents) {
		this.groupEvents = groupEvents;
	}

	public boolean isGroupGallery() {
		return groupGallery;
	}

	public void setGroupGallery(boolean groupGallery) {
		this.groupGallery = groupGallery;
	}

	public boolean isGroupMasterList() {
		return groupMasterList;
	}

	public void setGroupMasterList(boolean groupMasterList) {
		this.groupMasterList = groupMasterList;
	}

	public boolean isGroupItems() {
		return groupItems;
	}

	public void setGroupItems(boolean groupItems) {
		this.groupItems = groupItems;
	}

	public boolean isGroupMembers() {
		return groupMembers;
	}

	public void setGroupMembers(boolean groupMembers) {
		this.groupMembers = groupMembers;
	}

	public boolean isGroupGalleryUpload() {
		return groupGalleryUpload;
	}

	public void setGroupGalleryUpload(boolean groupGalleryUpload) {
		this.groupGalleryUpload = groupGalleryUpload;
	}

	public boolean isGroupGalleryDelete() {
		return groupGalleryDelete;
	}

	public void setGroupGalleryDelete(boolean groupGalleryDelete) {
		this.groupGalleryDelete = groupGalleryDelete;
	}

	public boolean isGroupEventEdit() {
		return groupEventEdit;
	}

	public void setGroupEventEdit(boolean groupEventEdit) {
		this.groupEventEdit = groupEventEdit;
	}

	public boolean isGroupAdminRead() {
		return groupAdminRead;
	}

	public void setGroupAdminRead(boolean groupAdminRead) {
		this.groupAdminRead = groupAdminRead;
	}

	public boolean isGroupNewsEdit() {
		return groupNewsEdit;
	}

	public void setGroupNewsEdit(boolean groupNewsEdit) {
		this.groupNewsEdit = groupNewsEdit;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public boolean isGroupAdminEdit() {
		return groupAdminEdit;
	}

	public void setGroupAdminEdit(boolean groupAdminEdit) {
		this.groupAdminEdit = groupAdminEdit;
	}

	public boolean isGroupMasterlistEdit() {
		return groupMasterlistEdit;
	}

	public void setGroupMasterlistEdit(boolean groupMasterlistEdit) {
		this.groupMasterlistEdit = groupMasterlistEdit;
	}

	public boolean isGroupItemsEdit() {
		return groupItemsEdit;
	}

	public void setGroupItemsEdit(boolean groupItemsEdit) {
		this.groupItemsEdit = groupItemsEdit;
	}

	public boolean isGroupMembersEdit() {
		return groupMembersEdit;
	}

	public void setGroupMembersEdit(boolean groupMembersEdit) {
		this.groupMembersEdit = groupMembersEdit;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<UsersPojo> getUsersPojoList() {
		return usersPojoList;
	}

	public void setUsersPojoList(List<UsersPojo> usersPojoList) {
		this.usersPojoList = usersPojoList;
	}

	public boolean isAdmissionOpen() {
		return admissionOpen;
	}

	public void setAdmissionOpen(boolean admissionOpen) {
		this.admissionOpen = admissionOpen;
	}

	public boolean isAdmissionAuto() {
		return admissionAuto;
	}

	public void setAdmissionAuto(boolean admissionAuto) {
		this.admissionAuto = admissionAuto;
	}

	public List<UsersPojo> getUsersPojoLobbyList() {
		return usersPojoLobbyList;
	}

	public void setUsersPojoLobbyList(List<UsersPojo> usersPojoLobbyList) {
		this.usersPojoLobbyList = usersPojoLobbyList;
	}

	public boolean isGroupAccessRightsEdit() {
		return groupAccessRightsEdit;
	}

	public void setGroupAccessRightsEdit(boolean groupAccessRightsEdit) {
		this.groupAccessRightsEdit = groupAccessRightsEdit;
	}

	public boolean isGroupUpgradesEdit() {
		return groupUpgradesEdit;
	}

	public void setGroupUpgradesEdit(boolean groupUpgradesEdit) {
		this.groupUpgradesEdit = groupUpgradesEdit;
	}

	public boolean isGroupHomeListEdit() {
		return groupHomeListEdit;
	}

	public void setGroupHomeListEdit(boolean groupHomeListEdit) {
		this.groupHomeListEdit = groupHomeListEdit;
	}

	public boolean isGroupComment() {
		return groupComment;
	}

	public void setGroupComment(boolean groupComment) {
		this.groupComment = groupComment;
	}

	public boolean isGroupCommentHide() {
		return groupCommentHide;
	}

	public void setGroupCommentHide(boolean groupCommentHide) {
		this.groupCommentHide = groupCommentHide;
	}

	public boolean isGroupEventModerating() {
		return groupEventModerating;
	}

	public void setGroupEventModerating(boolean groupEventModerating) {
		this.groupEventModerating = groupEventModerating;
	}

	public boolean isGroupLogs() {
		return groupLogs;
	}

	public void setGroupLogs(boolean groupLogs) {
		this.groupLogs = groupLogs;
	}

	public List<UsersPojo> getUsersPojoInviteList() {
		return usersPojoInviteList;
	}

	public void setUsersPojoInviteList(List<UsersPojo> usersPojoInviteList) {
		this.usersPojoInviteList = usersPojoInviteList;
	}

}
