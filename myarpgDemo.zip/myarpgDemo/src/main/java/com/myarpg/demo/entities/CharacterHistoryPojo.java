package com.myarpg.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.joda.time.DateTime;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class CharacterHistoryPojo {

	@GeneratedValue
	@Id
	private Long characterHistoryID;

	@ManyToOne(cascade = CascadeType.ALL)
	private CharactersPojo charactersPojo;

	@ManyToOne(cascade = CascadeType.ALL)
	private UsersPojo usersPojo;

	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm")
	private DateTime ownerDate;

	public CharacterHistoryPojo() {
	}

	public Long getCharacterHistoryID() {
		return characterHistoryID;
	}

	public void setCharacterHistoryID(Long characterHistoryID) {
		this.characterHistoryID = characterHistoryID;
	}

	public CharactersPojo getCharactersPojo() {
		return charactersPojo;
	}

	public void setCharactersPojo(CharactersPojo charactersPojo) {
		this.charactersPojo = charactersPojo;
	}

	public UsersPojo getUsersPojo() {
		return usersPojo;
	}

	public void setUsersPojo(UsersPojo usersPojo) {
		this.usersPojo = usersPojo;
	}

	public DateTime getOwnerDate() {
		return ownerDate;
	}

	public void setOwnerDate(DateTime ownerDate) {
		this.ownerDate = ownerDate;
	}

}
