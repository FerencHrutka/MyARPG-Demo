package com.myarpg.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myarpg.demo.entities.CensorPojo;
import com.myarpg.demo.repository.CensorRepository;

@Service
public class CensorService {

	CensorRepository censorRepository;

	@Autowired
	public void setCensorRepository(CensorRepository censorRepository) {
		this.censorRepository = censorRepository;
	}

	public List<CensorPojo> findAll() {
		return censorRepository.findAll();
	}
}
