package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.myarpg.demo.entities.ItemCategoriesPojo;

public interface ItemCategoriesRepository extends CrudRepository<ItemCategoriesPojo, Long> {

	List<ItemCategoriesPojo> findAll();

	Integer countByGroupID(Long groupID);

	Integer countByGroupIDAndSubItemCategoriesIDOrderByItemCategoriesID(Long groupID, long l);

	List<ItemCategoriesPojo> findByGroupIDAndUrl(Long groupID, String selectedItemCategoriesUrl);

	List<ItemCategoriesPojo> findByGroupID(Long groupID, Pageable pageable);

	List<ItemCategoriesPojo> findByGroupIDAndSubItemCategoriesIDOrderByItemCategoriesID(Long groupID, long l, Pageable pageable);

	ItemCategoriesPojo findByItemCategoriesID(Long itemCategoriesID);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM item_categories_pojo WHERE item_categoriesid = :itemCategoriesID ;", nativeQuery = true)
	public void deleteByItemCategoriesID(@Param("itemCategoriesID") Long itemCategoriesID);

}
