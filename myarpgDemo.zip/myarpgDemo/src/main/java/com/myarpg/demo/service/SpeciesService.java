package com.myarpg.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.myarpg.demo.entities.CharactersPojo;
import com.myarpg.demo.entities.GroupsPojo;
import com.myarpg.demo.entities.SpeciesPojo;
import com.myarpg.demo.repository.SpeciesRepository;

@Service
public class SpeciesService {

	private SpeciesRepository speciesRepository;

	@Autowired
	public void setSpeciesRepository(SpeciesRepository speciesRepository) {
		this.speciesRepository = speciesRepository;
	}

	UtilsService utilsService;

	@Autowired
	public void setUtilsService(UtilsService utilsService) {
		this.utilsService = utilsService;
	}

	public List<SpeciesPojo> findByGroupIDAndSpeciesUrl(Long groupID, String selectedSpeciesUrl, PageRequest pageRequest) {
		List<SpeciesPojo> selectedSpeciesPojo = null;
		List<SpeciesPojo> selectedSubSpeciesPojo = null;
		try {
			if (selectedSpeciesUrl.equals("all")) {
				selectedSpeciesPojo = speciesRepository.findByGroupID(groupID, pageRequest);
			} else if (selectedSpeciesUrl.equals("main")) {
				selectedSpeciesPojo = speciesRepository.findByGroupIDAndSubSpeciesIDOrderBySpeciesID(groupID, 0L, pageRequest);
			} else {
				selectedSpeciesPojo = speciesRepository.findByGroupIDAndUrl(groupID, selectedSpeciesUrl);
				selectedSubSpeciesPojo = speciesRepository.findByGroupIDAndSubSpeciesIDOrderBySpeciesID(groupID,
						selectedSpeciesPojo.get(0).getSpeciesID(), pageRequest);
				selectedSpeciesPojo.addAll(selectedSubSpeciesPojo);
			}
		} catch (Exception e) {
		}

		if (selectedSpeciesPojo != null) {
			return selectedSpeciesPojo;
		}
		return null;
	}

	public Integer countByGroupIDAndSpeciesUrl(Long groupID, String selectedSpeciesUrl) {
		List<SpeciesPojo> selectedSpeciesPojo = null;
		Integer speciesPojoCounter = 0;
		try {
			if (selectedSpeciesUrl.equals("all")) {
				speciesPojoCounter = speciesRepository.countByGroupID(groupID);
			} else if (selectedSpeciesUrl.equals("main")) {
				speciesPojoCounter = speciesRepository.countByGroupIDAndSubSpeciesIDOrderBySpeciesID(groupID, 0L);
			} else {
				selectedSpeciesPojo = speciesRepository.findByGroupIDAndUrl(groupID, selectedSpeciesUrl);
				speciesPojoCounter = speciesRepository.countByGroupIDAndSubSpeciesIDOrderBySpeciesID(groupID,
						selectedSpeciesPojo.get(0).getSpeciesID());
			}
		} catch (Exception e) {
		}

		if (speciesPojoCounter == 0) {
			speciesPojoCounter = 1;
		}

		return speciesPojoCounter;
	}

	public SpeciesPojo newSpecies(SpeciesPojo thymeleafSpeciesPojo, GroupsPojo selectedGroup, MultipartFile[] uploadedFiles) {
		SpeciesPojo speciesPojo = new SpeciesPojo();
		speciesPojo.setDescription(thymeleafSpeciesPojo.getDescription());
		speciesPojo.setGroupID(selectedGroup.getGroupID());
		speciesPojo.setName(thymeleafSpeciesPojo.getName());
		speciesPojo.setUrl(thymeleafSpeciesPojo.getName().replaceAll("[^\\p{Alpha}\\p{Digit}]+", "").toLowerCase());
		if (thymeleafSpeciesPojo.getSubSpeciesID() == null) {
			speciesPojo.setSubSpeciesID(0L);
		} else {
			speciesPojo.setSubSpeciesID(thymeleafSpeciesPojo.getSubSpeciesID());
		}

		speciesRepository.save(speciesPojo);
		CharactersPojo emptyCharactersPojo = new CharactersPojo();
		utilsService.uploadNewSpeciesOrCharacter("Species", uploadedFiles, selectedGroup, speciesPojo, emptyCharactersPojo);
		return speciesPojo;
	}
}
