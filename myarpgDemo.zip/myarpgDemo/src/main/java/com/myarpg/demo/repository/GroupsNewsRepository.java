package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.GroupsNewsPojo;

public interface GroupsNewsRepository extends CrudRepository<GroupsNewsPojo, Long> {

	List<GroupsNewsPojo> findBygroupsNewsID(Long groupsNewsID);

	GroupsNewsPojo findByGroupIDAndNumber(Long groupID, Integer number);

}
