package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.myarpg.demo.entities.ItemPropertiesPojo;

public interface ItemPropertiesRepository extends CrudRepository<ItemPropertiesPojo, Long> {

	List<ItemPropertiesPojo> findAll();

	List<ItemPropertiesPojo> findByItemID(Long itemID);

	ItemPropertiesPojo findByItemIDAndPosition(Long itemID, Integer position);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM item_properties_pojo WHERE item_propertiesid = :itemPropertiesID ;", nativeQuery = true)
	public void deleteByItemPropertiesID(@Param("itemPropertiesID") Long itemPropertiesID);
}
