package com.myarpg.demo.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;

@Entity
public class ItemCategoriesPojo {

	@GeneratedValue
	@Id
	private Long itemCategoriesID;
	private Long groupID;
	private String name;
	private String url;
	private Long subItemCategoriesID;

	@Column(length = 5000)
	private String description;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "itemCategoriesID")
	@OrderBy("number desc")
	private List<ItemsPojo> itemsPojo;
	
	@OneToOne
	private ImgStoragePojo imgStoragePojo;

	public ItemCategoriesPojo() {
	}

	public Long getItemCategoriesID() {
		return itemCategoriesID;
	}

	public void setItemCategoriesID(Long itemCategoriesID) {
		this.itemCategoriesID = itemCategoriesID;
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<ItemsPojo> getItemsPojo() {
		return itemsPojo;
	}

	public void setItemsPojo(List<ItemsPojo> itemsPojo) {
		this.itemsPojo = itemsPojo;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getSubItemCategoriesID() {
		return subItemCategoriesID;
	}

	public void setSubItemCategoriesID(Long subItemCategoriesID) {
		this.subItemCategoriesID = subItemCategoriesID;
	}

	public ImgStoragePojo getImgStoragePojo() {
		return imgStoragePojo;
	}

	public void setImgStoragePojo(ImgStoragePojo imgStoragePojo) {
		this.imgStoragePojo = imgStoragePojo;
	}


}
