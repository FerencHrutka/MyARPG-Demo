package com.myarpg.demo.service;

import java.util.List;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myarpg.demo.entities.EventPojo;
import com.myarpg.demo.entities.MessagePojo;
import com.myarpg.demo.entities.UsersPojo;
import com.myarpg.demo.repository.MessageRepository;

@Service
public class MessageService {

	MessageRepository messageRepository;

	@Autowired
	public void setMessageRepository(MessageRepository messageRepository) {
		this.messageRepository = messageRepository;
	}

	UsersService usersService;

	@Autowired
	public void setUsersService(UsersService usersService) {
		this.usersService = usersService;
	}

	public String newMessage(UsersPojo loggedUser, String messageTo, MessagePojo thymeleafMessagePojo, String newMessageSummernote) {
		UsersPojo selectedUsersPojo = usersService.findByuserNameIgnoreCase(messageTo);
		if (selectedUsersPojo == null) {
			return "userNotFound";
		}

		MessagePojo newMessagePojo = new MessagePojo();
		newMessagePojo.setSenderUsersPojo(loggedUser);
		newMessagePojo.setReciverUsersPojo(selectedUsersPojo);
		newMessagePojo.setSentTime(DateTime.now());
		newMessagePojo.setSubject(thymeleafMessagePojo.getSubject());
		newMessagePojo.setType("private");
		newMessagePojo.setUnread(true);
		newMessagePojo.setMessage(newMessageSummernote);

		messageRepository.save(newMessagePojo);

		return "ok";
	}

	public MessagePojo selectedMessage(UsersPojo loggedUser, MessagePojo thymeleafMessagePojo) {
		MessagePojo selectedMessagePojo = null;
		try {
			selectedMessagePojo = messageRepository.findBymessageID(thymeleafMessagePojo.getMessageID());
		} catch (Exception e) {
		}

		if (selectedMessagePojo == null) {
			return null;
		} else {
			boolean recieverCanRead = false;
			boolean senderCanRead = false;
			for (int i = 0; i < loggedUser.getReciverMessagePojo().size(); i++) {
				if (loggedUser.getReciverMessagePojo().get(i).getMessageID() == selectedMessagePojo.getMessageID()) {
					recieverCanRead = true;
					break;
				}
			}

			if (!recieverCanRead) {
				for (int i = 0; i < loggedUser.getSenderMessagePojo().size(); i++) {
					if (loggedUser.getSenderMessagePojo().get(i).getMessageID() == selectedMessagePojo.getMessageID()) {
						senderCanRead = true;
						break;
					}
				}
			}

			if (senderCanRead) {
				return selectedMessagePojo;

			} else if (recieverCanRead) {
				selectedMessagePojo.setUnread(false);
				messageRepository.save(selectedMessagePojo);
				return selectedMessagePojo;
			} else {
				return null;
			}
		}
	}

	public void simpleEventManuallySubmissionApproval(UsersPojo usersPojo, EventPojo selectedEventPojo, List<String> rewardItems) {
		MessagePojo newMessagePojo = new MessagePojo();
		newMessagePojo.setSenderUsersPojo(usersService.getRobotUserPojo());
		newMessagePojo.setReciverUsersPojo(usersPojo);
		newMessagePojo.setSentTime(DateTime.now());
		newMessagePojo.setSubject("Event submission has been approved.");
		newMessagePojo.setType("robot");
		newMessagePojo.setUnread(true);
		String rewardString = "";
		for (int i = 0; i < rewardItems.size(); i++) {
			rewardString = rewardString + rewardItems.get(i) + " <br> ";
		}

		newMessagePojo.setMessage("Your event submission has been approved.<br> Event: '" + selectedEventPojo.getTitle()
				+ "'<br> You have received the following:<br>" + rewardString);

		messageRepository.save(newMessagePojo);
	}

	public void simpleEventManuallySubmissionRejected(UsersPojo usersPojo, EventPojo selectedEventPojo,
			String explanationForParticipantReject) {
		MessagePojo newMessagePojo = new MessagePojo();
		newMessagePojo.setSenderUsersPojo(usersService.getRobotUserPojo());
		newMessagePojo.setReciverUsersPojo(usersPojo);
		newMessagePojo.setSentTime(DateTime.now());
		newMessagePojo.setSubject("Event submission has been rejected.");
		newMessagePojo.setType("robot");
		newMessagePojo.setUnread(true);
		if (!explanationForParticipantReject.equals("")) {
			newMessagePojo.setMessage("Your event submission has been rejected.<br> Event: '" + selectedEventPojo.getTitle()
					+ "' <br> Explanation: " + explanationForParticipantReject);
		} else {
			newMessagePojo.setMessage("Your event submission has been rejected.<br> Event: '" + selectedEventPojo.getTitle());
		}

		messageRepository.save(newMessagePojo);
	}

}
