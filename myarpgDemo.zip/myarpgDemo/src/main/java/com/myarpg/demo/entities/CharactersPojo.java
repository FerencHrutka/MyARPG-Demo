package com.myarpg.demo.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderBy;

@Entity
public class CharactersPojo {

	@GeneratedValue
	@Id
	private Long characterID;
	private Long speciesID;
	private String name;

	@ManyToOne(cascade = CascadeType.ALL)
	private UsersPojo artistUsersPojo;	
	private Long number;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "characterID", nullable = true)
	@OrderBy("position ASC")
	private List<CharacterPropertiesPojo> characterPropertiesPojo;
	
	@OneToOne
	private ImgStoragePojo imgStoragePojo;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "characterID", nullable = true)
	@OrderBy("characterHistoryID ASC")
	private List<CharacterHistoryPojo> characterHistoryPojo;

	public CharactersPojo() {
	}

	public Long getCharacterID() {
		return characterID;
	}

	public void setCharacterID(Long characterID) {
		this.characterID = characterID;
	}

	public Long getSpeciesID() {
		return speciesID;
	}

	public void setSpeciesID(Long speciesID) {
		this.speciesID = speciesID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getNumber() {
		return number;
	}

	public void setNumber(Long number) {
		this.number = number;
	}

	public List<CharacterPropertiesPojo> getCharacterPropertiesPojo() {
		return characterPropertiesPojo;
	}

	public void setCharacterPropertiesPojo(List<CharacterPropertiesPojo> characterPropertiesPojo) {
		this.characterPropertiesPojo = characterPropertiesPojo;
	}

	public UsersPojo getArtistUsersPojo() {
		return artistUsersPojo;
	}

	public void setArtistUsersPojo(UsersPojo artistUsersPojo) {
		this.artistUsersPojo = artistUsersPojo;
	}

	public ImgStoragePojo getImgStoragePojo() {
		return imgStoragePojo;
	}

	public void setImgStoragePojo(ImgStoragePojo imgStoragePojo) {
		this.imgStoragePojo = imgStoragePojo;
	}

	public List<CharacterHistoryPojo> getCharacterHistoryPojo() {
		return characterHistoryPojo;
	}

	public void setCharacterHistoryPojo(List<CharacterHistoryPojo> characterHistoryPojo) {
		this.characterHistoryPojo = characterHistoryPojo;
	}

	

	
}
