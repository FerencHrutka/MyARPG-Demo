package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.myarpg.demo.entities.EventParticipantPojo;

public interface EventParticipantRepository extends CrudRepository<EventParticipantPojo, Long> {

	List<EventParticipantPojo> findAll();

	List<EventParticipantPojo> findByEventIDAndStatusOrderByEventParticipantID(Long eventID, String string);

	EventParticipantPojo findByEventParticipantID(Long eventParticipantID);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM event_participant_pojo WHERE eventid = :eventid ;", nativeQuery = true)
	public void deleteByEventID(@Param("eventid") Long eventid);

	@Query(value = "SELECT * FROM event_participant_pojo WHERE eventid = :eventID AND users_pojo_userid = :userID ;", nativeQuery = true)
	List<EventParticipantPojo> findByUserIDAndEventID(@Param("userID") Long userID, @Param("eventID") Long eventID);

	List<EventParticipantPojo> findByEventIDAndStatusNotInOrderByEventParticipantID(Long eventID, List<String> status);

}
