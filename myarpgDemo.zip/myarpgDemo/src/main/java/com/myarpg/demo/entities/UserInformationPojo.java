package com.myarpg.demo.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class UserInformationPojo {

	@Id
	@GeneratedValue
	private Long UserInformationID;

	@OneToOne(mappedBy = "userInformationPojo")
	@JoinColumn
	private UsersPojo usersPojo;

	@Column(length = 4000)
	private String aboutMe;
	
	public UserInformationPojo() {
	}

	public Long getUserInformationID() {
		return UserInformationID;
	}

	public void setUserInformationID(Long userInformationID) {
		UserInformationID = userInformationID;
	}

	public UsersPojo getUsersPojo() {
		return usersPojo;
	}

	public void setUsersPojo(UsersPojo usersPojo) {
		this.usersPojo = usersPojo;
	}

	public String getAboutMe() {
		return aboutMe;
	}

	public void setAboutMe(String aboutMe) {
		this.aboutMe = aboutMe;
	}

}
