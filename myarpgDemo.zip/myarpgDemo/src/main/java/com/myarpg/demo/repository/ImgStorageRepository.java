package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.myarpg.demo.entities.ImgStoragePojo;

public interface ImgStorageRepository extends CrudRepository<ImgStoragePojo, Long>{
	
	List<ImgStoragePojo> findAllByOrderByImgStorageIDDesc();

	ImgStoragePojo findByImageKey(String random16Char);

	ImgStoragePojo findByServerPath(String serverPath);

	List<ImgStoragePojo> findByGroupsPojoGroupIDOrderByUploadTimeDesc(Long groupID);

	ImgStoragePojo findByImgStorageID(Long imgStorageID);

	ImgStoragePojo findByGroupsPojoGroupIDAndImageKey(Long groupID, String imageKey);

	@Modifying
	@Transactional
	@Query(value = "DELETE FROM img_storage_pojo WHERE img_storageid = :imgStorageID ;", nativeQuery = true)
	public void deleteByImgStorageID(@Param("imgStorageID") Long imgStorageID);
	
	
	List<ImgStoragePojo> findFirst20ByTopicTypeOrderByImgStorageIDDesc(String topicType);
	
	List<ImgStoragePojo> findByTopicTypeOrderByImgStorageIDDesc(String topicType, Pageable pageable);

	Integer countByTopicType(String string);

	List<ImgStoragePojo> findFirst20ByOrderByNumberOfViewsDesc();

	List<ImgStoragePojo> findFirst20ByOrderByNumberOfCommentsDesc();
	
	List<ImgStoragePojo>findByOrderByNumberOfViewsDesc(Pageable pageable);
	
	List<ImgStoragePojo> findByOrderByNumberOfCommentsDesc(Pageable pageable);

	List<ImgStoragePojo> findByUsersPojoUserIDOrderByUploadTimeDesc(Long userID);

	List<ImgStoragePojo> findFirst20ByGroupsPojoGroupIDOrderByNumberOfViewsDesc(Long groupID);

	List<ImgStoragePojo> findFirst20ByGroupsPojoGroupIDOrderByNumberOfCommentsDesc(Long groupID);

	List<ImgStoragePojo> findFirst20ByGroupsPojoGroupIDAndTopicTypeOrderByImgStorageIDDesc(Long groupID, String string);
}
