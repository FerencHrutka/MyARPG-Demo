package com.myarpg.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.joda.time.DateTime;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class EventParticipantPojo {

	@GeneratedValue
	@Id
	private Long eventParticipantID;
	private Long eventID;

	@OneToOne(cascade = CascadeType.ALL)
	private UsersPojo usersPojo;

	@OneToOne(cascade = CascadeType.ALL)
	private ImgStoragePojo imgStoragePojo;
	private String status;
	
	@DateTimeFormat(pattern = "yyyy.MM.dd HH:mm")
	private DateTime timestamp;

	public EventParticipantPojo() {
	}

	public Long getEventParticipantID() {
		return eventParticipantID;
	}

	public void setEventParticipantID(Long eventParticipantID) {
		this.eventParticipantID = eventParticipantID;
	}

	public Long getEventID() {
		return eventID;
	}

	public void setEventID(Long eventID) {
		this.eventID = eventID;
	}

	public UsersPojo getUsersPojo() {
		return usersPojo;
	}

	public void setUsersPojo(UsersPojo usersPojo) {
		this.usersPojo = usersPojo;
	}

	public ImgStoragePojo getImgStoragePojo() {
		return imgStoragePojo;
	}

	public void setImgStoragePojo(ImgStoragePojo imgStoragePojo) {
		this.imgStoragePojo = imgStoragePojo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public DateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(DateTime timestamp) {
		this.timestamp = timestamp;
	}

	
}
