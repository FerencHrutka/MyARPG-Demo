package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.myarpg.demo.entities.CommentPojo;

public interface CommentRepository extends CrudRepository<CommentPojo, Long> {
	
	List<CommentPojo> findAll();

	CommentPojo findByCommentID(Long commentID);
	
	@Modifying
	@Transactional
	@Query(value = "DELETE FROM comment_pojo WHERE img_storageid = :imgStorageID ;", nativeQuery = true)
	public void deleteByImgStorageID(@Param("imgStorageID") Long imgStorageID);

}
