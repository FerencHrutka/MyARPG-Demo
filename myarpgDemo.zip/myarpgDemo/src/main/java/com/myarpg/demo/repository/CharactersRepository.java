package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.myarpg.demo.entities.CharactersPojo;

public interface CharactersRepository extends CrudRepository<CharactersPojo, Long> {

	List<CharactersPojo> findAll();

	CharactersPojo findByName(String valami);
	
	Long findFirstByOrderByNumberDesc();

	List<CharactersPojo> findBySpeciesID(Long speciesID, Pageable pageable);
	
	CharactersPojo findFirstBySpeciesIDOrderByCharacterIDDesc(Long speciesID);

	CharactersPojo findByNumberAndSpeciesID(Long selectedCharacterNumber, Long speciesID);

	CharactersPojo findByCharacterID(Long characterID);
	
	@Modifying
	@Transactional
	@Query(value = "DELETE FROM characters_pojo WHERE characterid = :characterID ;", nativeQuery = true)
	public void deleteByCharacterID(@Param("characterID") Long characterID);

	Integer countBySpeciesID(Long speciesID);
}
