package com.myarpg.demo.entities;

public class PaginationPojo {

	private Integer pageNumber;
	private Integer pageSize;
	private String pageSortBy;
	private String pageDirection;
	private Integer numbersOfPages;

	public PaginationPojo() {
	}

	public Integer getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getPageSortBy() {
		return pageSortBy;
	}

	public void setPageSortBy(String pageSortBy) {
		this.pageSortBy = pageSortBy;
	}

	public String getPageDirection() {
		return pageDirection;
	}

	public void setPageDirection(String pageDirection) {
		this.pageDirection = pageDirection;
	}

	public Integer getNumbersOfPages() {
		return numbersOfPages;
	}

	public void setNumbersOfPages(Integer numbersOfPages) {
		this.numbersOfPages = numbersOfPages;
	}

}
