package com.myarpg.demo.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;

@Entity
public class GroupsPojo {

	@Id
	@GeneratedValue
	private Long groupID;

	@OneToMany(cascade = CascadeType.ALL)
	@OrderBy("accessid ASC")
	@JoinColumn(name = "groupid", referencedColumnName = "groupid")
	private List<AccessPojo> accessPojo;

	@OneToMany(cascade = CascadeType.ALL)
	@OrderBy("position DESC")
	@JoinColumn(name = "groupid", referencedColumnName = "groupid")
	private List<GroupsHomePojo> groupsHomePojo;

	@OneToMany(cascade = CascadeType.ALL)
	@OrderBy("newsPostedTime DESC")
	@JoinColumn(name = "groupid", referencedColumnName = "groupid")
	private List<GroupsNewsPojo> groupsNewsPojo;

	@OneToMany(cascade = CascadeType.ALL)
	@OrderBy("eventID ASC")
	@JoinColumn(name = "groupid", referencedColumnName = "groupid")
	private List<EventPojo> eventPojo;

	@OneToMany(cascade = CascadeType.ALL)
	@OrderBy("UpgradeGroupID ASC")
	@JoinColumn(name = "groupid", referencedColumnName = "groupid")
	private List<UpgradeGroupPojo> upgradeGroupPojo;

	private String name;
	private String creator;
	private String creatingTime;
	private String url;
	private String logo;
	private String menuBackground;

	@Column(length = 500)
	private String siteBackground;
	private String layersBackground;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "groupID", nullable = true)
	@OrderBy("logID DESC")
	private List<LogPojo> logPojo;

	public GroupsPojo() {
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatingTime() {
		return creatingTime;
	}

	public void setCreatingTime(String creatingTime) {
		this.creatingTime = creatingTime;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public List<AccessPojo> getAccessPojo() {
		return accessPojo;
	}

	public void setAccessPojo(List<AccessPojo> accessPojo) {
		this.accessPojo = accessPojo;
	}

	public List<GroupsHomePojo> getGroupsHomePojo() {
		return groupsHomePojo;
	}

	public void setGroupsHomePojo(List<GroupsHomePojo> groupsHomePojo) {
		this.groupsHomePojo = groupsHomePojo;
	}

	public List<GroupsNewsPojo> getGroupsNewsPojo() {
		return groupsNewsPojo;
	}

	public void setGroupsNewsPojo(List<GroupsNewsPojo> groupsNewsPojo) {
		this.groupsNewsPojo = groupsNewsPojo;
	}

	public List<EventPojo> getEventPojo() {
		return eventPojo;
	}

	public void setEventPojo(List<EventPojo> eventPojo) {
		this.eventPojo = eventPojo;
	}

	public List<UpgradeGroupPojo> getUpgradeGroupPojo() {
		return upgradeGroupPojo;
	}

	public void setUpgradeGroupPojo(List<UpgradeGroupPojo> upgradeGroupPojo) {
		this.upgradeGroupPojo = upgradeGroupPojo;
	}

	public String getMenuBackground() {
		return menuBackground;
	}

	public void setMenuBackground(String menuBackground) {
		this.menuBackground = menuBackground;
	}

	public String getSiteBackground() {
		return siteBackground;
	}

	public void setSiteBackground(String siteBackground) {
		this.siteBackground = siteBackground;
	}

	public String getLayersBackground() {
		return layersBackground;
	}

	public void setLayersBackground(String layersBackground) {
		this.layersBackground = layersBackground;
	}

	public List<LogPojo> getLogPojo() {
		return logPojo;
	}

	public void setLogPojo(List<LogPojo> logPojo) {
		this.logPojo = logPojo;
	}

}
