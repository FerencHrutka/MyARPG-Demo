package com.myarpg.demo.service;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myarpg.demo.entities.CharacterHistoryPojo;
import com.myarpg.demo.entities.CharactersPojo;
import com.myarpg.demo.entities.UsersPojo;
import com.myarpg.demo.repository.CharacterHistoryRepository;
import com.myarpg.demo.repository.CharactersRepository;

@Service
public class CharactersService {

	CharactersRepository charactersRepository;

	@Autowired
	public void setCharactersRepository(CharactersRepository charactersRepository) {
		this.charactersRepository = charactersRepository;
	}

	CharacterHistoryRepository characterHistoryRepository;

	@Autowired
	public void setCharacterHistoryRepository(CharacterHistoryRepository characterHistoryRepository) {
		this.characterHistoryRepository = characterHistoryRepository;
	}

	UsersService usersService;

	@Autowired
	public void setUsersService(UsersService usersService) {
		this.usersService = usersService;
	}

	public void newCurrentOwner(CharactersPojo selectedCharactersPojo, String selectedUserName) {
		UsersPojo selectedUsersPojo = null;

		try {
			selectedUsersPojo = usersService.findByuserNameIgnoreCase(selectedUserName);
		} catch (Exception e) {
		}

		if (selectedUsersPojo != null) {
			CharacterHistoryPojo characterHistoryPojo = new CharacterHistoryPojo();
			characterHistoryPojo.setCharactersPojo(selectedCharactersPojo);
			characterHistoryPojo.setUsersPojo(selectedUsersPojo);
			characterHistoryPojo.setOwnerDate(DateTime.now());
			selectedCharactersPojo.getCharacterHistoryPojo().add(characterHistoryPojo);
			charactersRepository.save(selectedCharactersPojo);
		}

	}

	public void newArtist(CharactersPojo selectedCharactersPojo, String selectedUserName) {
		UsersPojo selectedUsersPojo = null;

		try {
			selectedUsersPojo = usersService.findByuserNameIgnoreCase(selectedUserName);
		} catch (Exception e) {
		}

		if (selectedUsersPojo != null) {
			selectedCharactersPojo.setArtistUsersPojo(selectedUsersPojo);
			charactersRepository.save(selectedCharactersPojo);
		}

	}

}
