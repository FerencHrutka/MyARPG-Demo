package com.myarpg.demo.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class UsersAddressPojo {

	@Id
	@GeneratedValue
	private Long usersAddressID;

	@OneToOne(mappedBy = "usersAddressPojo")
	@JoinColumn
	private UsersPojo usersPojo;
	private String userStreetAddress1;
	private String userStreetAddress2;
	private String userCityAddress;
	private String userStateAddress;
	private String userZipAddress;
	private String userCountryAddress;
	private String userFirstName;
	private String userLastName;

	public UsersAddressPojo() {
	}

	public Long getUsersAddressID() {
		return usersAddressID;
	}

	public void setUsersAddressID(Long usersAddressID) {
		this.usersAddressID = usersAddressID;
	}

	public UsersPojo getUsersPojo() {
		return usersPojo;
	}

	public void setUsersPojo(UsersPojo usersPojo) {
		this.usersPojo = usersPojo;
	}

	public String getUserStreetAddress1() {
		return userStreetAddress1;
	}

	public void setUserStreetAddress1(String userStreetAddress1) {
		this.userStreetAddress1 = userStreetAddress1;
	}

	public String getUserStreetAddress2() {
		return userStreetAddress2;
	}

	public void setUserStreetAddress2(String userStreetAddress2) {
		this.userStreetAddress2 = userStreetAddress2;
	}

	public String getUserCityAddress() {
		return userCityAddress;
	}

	public void setUserCityAddress(String userCityAddress) {
		this.userCityAddress = userCityAddress;
	}

	public String getUserStateAddress() {
		return userStateAddress;
	}

	public void setUserStateAddress(String userStateAddress) {
		this.userStateAddress = userStateAddress;
	}

	public String getUserZipAddress() {
		return userZipAddress;
	}

	public void setUserZipAddress(String userZipAddress) {
		this.userZipAddress = userZipAddress;
	}

	public String getUserCountryAddress() {
		return userCountryAddress;
	}

	public void setUserCountryAddress(String userCountryAddress) {
		this.userCountryAddress = userCountryAddress;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}
}
