package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.UpgradeUserPojo;

public interface UpgradeUserRepository extends CrudRepository<UpgradeUserPojo, Long >{
	
	List<UpgradeUserPojo> findAll();

	UpgradeUserPojo findByUserIDAndName(Long userID, String upgradeName);

}
