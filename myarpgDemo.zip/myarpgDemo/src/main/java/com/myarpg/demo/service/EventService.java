package com.myarpg.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.myarpg.demo.entities.AccessPojo;
import com.myarpg.demo.entities.EventParticipantPojo;
import com.myarpg.demo.entities.EventPojo;
import com.myarpg.demo.entities.GroupsPojo;
import com.myarpg.demo.entities.ImgStoragePojo;
import com.myarpg.demo.entities.UsersPojo;
import com.myarpg.demo.repository.AccessRepository;
import com.myarpg.demo.repository.EventParticipantRepository;
import com.myarpg.demo.repository.EventRepository;

@Service
public class EventService {
	EventRepository eventRepository;

	@Autowired
	public void setEventRepository(EventRepository eventRepository) {
		this.eventRepository = eventRepository;
	}

	UtilsService utilsService;

	@Autowired
	public void setUtilsService(UtilsService utilsService) {
		this.utilsService = utilsService;
	}

	AccessRepository accessRepository;

	@Autowired
	public void setAccessRepository(AccessRepository accessRepository) {
		this.accessRepository = accessRepository;
	}

	EventParticipantRepository eventParticipantRepository;

	@Autowired
	public void setEventParticipantRepository(EventParticipantRepository eventParticipantRepository) {
		this.eventParticipantRepository = eventParticipantRepository;
	}

	public void newEventOfficial(EventPojo thymeleafEventPojo, GroupsPojo selectedGroup, UsersPojo loggedUser,
			MultipartFile[] uploadedFiles) {

		thymeleafEventPojo.setGroupID(selectedGroup.getGroupID());
		EventPojo selectedEventPojo = null;
		try {
			selectedEventPojo = eventRepository.findFirstByGroupIDAndCategoryOrderByEventIDDesc(selectedGroup.getGroupID(), "official");
		} catch (Exception e) {
		}

		if (selectedEventPojo == null) {
			selectedEventPojo = new EventPojo();
			selectedEventPojo.setNumber(0L);
		}

		Long newSetNumberValue = new Long(selectedEventPojo.getNumber() + 1);
		thymeleafEventPojo.setNumber(newSetNumberValue);

		thymeleafEventPojo.setUrl(selectedGroup.getUrl() + "/event/official/" + thymeleafEventPojo.getNumber());
		thymeleafEventPojo.setCreator(loggedUser.getUserName());

		eventRepository.save(thymeleafEventPojo);

		ImgStoragePojo imgStoragePojo = utilsService.uploadEventCover(uploadedFiles, selectedGroup, thymeleafEventPojo);

		thymeleafEventPojo.setImgStoragePojo(imgStoragePojo);

		eventRepository.save(thymeleafEventPojo);

	}

	public EventPojo findEventByGroupIDAndEventCategoryAndEventNumber(GroupsPojo selectedGroup, String selectedCategory,
			Long selectedEventNumber) {
		return eventRepository.findByGroupIDAndCategoryAndNumber(selectedGroup.getGroupID(), selectedCategory, selectedEventNumber);
	}

	public EventPojo editEventOfficial(EventPojo thymeleafEventPojo, GroupsPojo selectedGroup, UsersPojo loggedUser) {
		EventPojo selectedEventPojo = null;
		try {
			selectedEventPojo = eventRepository.findFirstByGroupIDAndCategoryAndNumberOrderByEventIDDesc(selectedGroup.getGroupID(),
					"official", thymeleafEventPojo.getNumber());
		} catch (Exception e) {
		}

		if (selectedEventPojo == null) {
			return null;
		}
		selectedEventPojo.setColor(thymeleafEventPojo.getColor());
		selectedEventPojo.setEnd(thymeleafEventPojo.getEnd());
		selectedEventPojo.setLastEditedBy(loggedUser.getUserName());
		selectedEventPojo.setStart(thymeleafEventPojo.getStart());
		selectedEventPojo.setTitle(thymeleafEventPojo.getTitle());
		if (!selectedEventPojo.getStatus().equals("Finished")) {
			selectedEventPojo.setStatus(thymeleafEventPojo.getStatus());
		}
		eventRepository.save(selectedEventPojo);
		return selectedEventPojo;
	}

	public ArrayList<String> getAccessNameByAccessID(EventPojo selectedEventPojo) {
		ArrayList<String> accessNameList = new ArrayList<String>();
		String[] accessIDs = selectedEventPojo.getAccesPojoList().split(",");

		for (int i = 0; i < accessIDs.length; i++) {
			long accessIDsLong = Long.parseLong(accessIDs[i]);
			AccessPojo selectedAccessPojo = accessRepository.findByaccessID(accessIDsLong);
			accessNameList.add(selectedAccessPojo.getName());
		}
		return accessNameList;
	}

	public EventPojo findSelectedEventPojo(Long eventID) {
		EventPojo selectedEventPojo = null;
		try {
			selectedEventPojo = eventRepository.findByEventID(eventID);
		} catch (Exception e) {
		}

		if (selectedEventPojo == null) {
			return null;
		}
		return selectedEventPojo;
	}

	public List<String> simpleEventManuallySubmissionApproval(EventParticipantPojo selectedEventParticipantPojo,
			EventPojo selectedEventPojo) {
		List<String> rewardItems = makeReward(selectedEventPojo, selectedEventParticipantPojo.getUsersPojo());
		selectedEventParticipantPojo.setStatus("manually approval");
		eventParticipantRepository.save(selectedEventParticipantPojo);
		return rewardItems;
	}

	public void simpleEventManuallySubmissionRejected(EventParticipantPojo selectedEventParticipantPojo, EventPojo selectedEventPojo) {
		selectedEventParticipantPojo.setStatus("manually rejected");
		eventParticipantRepository.save(selectedEventParticipantPojo);
	}

	public List<String> makeReward(EventPojo selectedEventPojo, UsersPojo loggedUser) {
		List<String> rewardItems = new ArrayList<String>();
		// ... MyARPG.com sesitive information
		return rewardItems;
	}

	public List<EventParticipantPojo> findByEventIDAndStatusOrderByEventParticipantID(Long eventID, String string) {
		return eventParticipantRepository.findByEventIDAndStatusOrderByEventParticipantID(eventID, string);
	}

	public List<EventParticipantPojo> findByEventIDAndStatusNotInOrderByEventParticipantID(Long eventID, List<String> status) {
		return eventParticipantRepository.findByEventIDAndStatusNotInOrderByEventParticipantID(eventID, status);
	}

	public EventParticipantPojo findByEventParticipantID(Long eventParticipantID) {
		return eventParticipantRepository.findByEventParticipantID(eventParticipantID);
	}

	public String getEventLimit(UsersPojo loggedUser, EventPojo selectedEventPojo) {

		// Error védelem anonymousUser -hez:
		if (loggedUser.getUserID() == null) {
			loggedUser.setUserID(0L);
		}

		if (selectedEventPojo.getParticipantLimit().equals("User limit") && selectedEventPojo.getRepeatable().equals("Only once")) {
			List<EventParticipantPojo> eventParticipantPojo = null;

			try {
				eventParticipantPojo = eventParticipantRepository.findByUserIDAndEventID(loggedUser.getUserID(),
						selectedEventPojo.getEventID());
			} catch (Exception e) {
			}

			// Ha részt vette már a User az eseményen, de visszautasították.
			if (eventParticipantPojo != null) {

				// Megkeressük hogy van-e benne 'approve' vagy 'lobby'.
				// HA igen akkor visszaküldjük hogy elérte a limitet. Itt tovább lehet
				// fejleszteni, hogy mennyisszer érheti el a 'lobby' vagy az 'approve'-ot .
				for (int i = 0; i < eventParticipantPojo.size(); i++) {
					if (eventParticipantPojo.get(i).getStatus().contains("approval")
							|| eventParticipantPojo.get(i).getStatus().contains("lobby")) {
						return "User limit reached";
					}
					;
				}

				return "";
			}

		}

		if (selectedEventPojo.getParticipantLimit().equals("User limit") && selectedEventPojo.getRepeatable().equals("Only once per day")) {

			List<EventParticipantPojo> eventParticipantPojo = null;

			try {
				eventParticipantPojo = eventParticipantRepository.findByUserIDAndEventID(loggedUser.getUserID(),
						selectedEventPojo.getEventID());
			} catch (Exception e) {
			}

			// Ha részt vette már a User az eseményen, de visszautasították.
			if (eventParticipantPojo != null) {

				// Megkeressük hogy van-e benne 'approve' vagy 'lobby'.
				for (int i = 0; i < eventParticipantPojo.size(); i++) {
					if (eventParticipantPojo.get(i).getTimestamp().getDayOfYear() == DateTime.now().getDayOfYear()
							&& (eventParticipantPojo.get(i).getStatus().contains("approval")
									|| eventParticipantPojo.get(i).getStatus().contains("lobby"))) {
						return "Repeatable limit reached";
					}
					;
				}

				return "";
			}

		}

		return "";
	}

	public String checkEventIsExpired(EventPojo selectedEventPojo) {
		if (selectedEventPojo.getEnd().isAfter(DateTime.now())) {
			return "no";
		}
		return "yes";
	}

	public String checkRaffleStatus(EventPojo selectedEventPojo) {
		if (selectedEventPojo.getWinner().equals("Raffle")) {
			for (int i = 0; i < selectedEventPojo.getEventParticipantPojo().size(); i++) {
				if (selectedEventPojo.getEventParticipantPojo().get(i).getStatus().equals("Did not win")
						|| selectedEventPojo.getEventParticipantPojo().get(i).getStatus().equals("Has won")) {
					return "Has been raffled";
				}
			}
			return "Ready for raffle";
		}
		return "";
	}

}
