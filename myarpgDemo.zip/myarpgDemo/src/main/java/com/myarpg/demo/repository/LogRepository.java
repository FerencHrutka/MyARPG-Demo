package com.myarpg.demo.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;

import com.myarpg.demo.entities.LogPojo;

public interface LogRepository extends CrudRepository<LogPojo, Long> {

	List<LogPojo> findAll();

	Integer countByGroupID(Long groupID);

	List<LogPojo> findByGroupID(Long groupID, Pageable pageable);

	List<LogPojo> findByUserID(Long userID, Pageable pageable);
}
