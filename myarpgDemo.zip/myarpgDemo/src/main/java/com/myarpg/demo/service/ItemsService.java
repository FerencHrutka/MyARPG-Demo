package com.myarpg.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.myarpg.demo.entities.GroupsPojo;
import com.myarpg.demo.entities.ImgStoragePojo;
import com.myarpg.demo.entities.ItemCategoriesPojo;
import com.myarpg.demo.entities.ItemsPojo;
import com.myarpg.demo.repository.ItemCategoriesRepository;

@Service
public class ItemsService {

	ItemCategoriesRepository itemCategoriesRepository;

	@Autowired
	public void setItemCategoriesRepository(ItemCategoriesRepository itemCategoriesRepository) {
		this.itemCategoriesRepository = itemCategoriesRepository;
	}

	UtilsService utilsService;

	@Autowired
	public void setUtilsService(UtilsService utilsService) {
		this.utilsService = utilsService;
	}

	public Integer countByGroupIDAndItemCategoriesUrl(Long groupID, String selectedItemCategoriesUrl) {
		List<ItemCategoriesPojo> selectedItemCategoriesPojo = null;
		Integer itemCategoriesPojoCounter = 0;

		try {
			if (selectedItemCategoriesUrl.equals("all")) {
				itemCategoriesPojoCounter = itemCategoriesRepository.countByGroupID(groupID);
			} else if (selectedItemCategoriesUrl.equals("main")) {
				itemCategoriesPojoCounter = itemCategoriesRepository.countByGroupIDAndSubItemCategoriesIDOrderByItemCategoriesID(groupID,
						0L);
			} else {
				selectedItemCategoriesPojo = itemCategoriesRepository.findByGroupIDAndUrl(groupID, selectedItemCategoriesUrl);
				itemCategoriesPojoCounter = itemCategoriesRepository.countByGroupIDAndSubItemCategoriesIDOrderByItemCategoriesID(groupID,
						selectedItemCategoriesPojo.get(0).getItemCategoriesID());
			}
		} catch (Exception e) {
		}

		if (itemCategoriesPojoCounter == 0) {
			itemCategoriesPojoCounter = 1;
		}

		return itemCategoriesPojoCounter;
	}

	public List<ItemCategoriesPojo> findByGroupIDAndItemCategoriesUrl(GroupsPojo selectedGroup, String selectedItemCategoriesUrl,
			PageRequest pageRequest) {
		List<ItemCategoriesPojo> selectedItemCategoriesPojo = null;
		List<ItemCategoriesPojo> selectedSubItemCategoriesPojo = null;

		try {
			if (selectedItemCategoriesUrl.equals("all")) {
				selectedItemCategoriesPojo = itemCategoriesRepository.findByGroupID(selectedGroup.getGroupID(), pageRequest);
			} else if (selectedItemCategoriesUrl.equals("main")) {
				selectedItemCategoriesPojo = itemCategoriesRepository
						.findByGroupIDAndSubItemCategoriesIDOrderByItemCategoriesID(selectedGroup.getGroupID(), 0L, pageRequest);
			} else {
				selectedItemCategoriesPojo = itemCategoriesRepository.findByGroupIDAndUrl(selectedGroup.getGroupID(),
						selectedItemCategoriesUrl);
				selectedSubItemCategoriesPojo = itemCategoriesRepository.findByGroupIDAndSubItemCategoriesIDOrderByItemCategoriesID(
						selectedGroup.getGroupID(), selectedItemCategoriesPojo.get(0).getItemCategoriesID(), pageRequest);
				selectedItemCategoriesPojo.addAll(selectedSubItemCategoriesPojo);
			}
		} catch (Exception e) {
		}

		if (selectedItemCategoriesPojo != null) {
			return selectedItemCategoriesPojo;
		}
		return null;

	}

	public ItemCategoriesPojo newItemCategories(ItemCategoriesPojo thymeleafItemCategoriesPojo, GroupsPojo selectedGroup,
			MultipartFile[] uploadedFiles, String banner, String imageSize, String imageSizeWidthPixel) {
		ItemCategoriesPojo itemCategoriesPojo = new ItemCategoriesPojo();
		itemCategoriesPojo.setDescription(thymeleafItemCategoriesPojo.getDescription());
		itemCategoriesPojo.setGroupID(selectedGroup.getGroupID());
		itemCategoriesPojo.setName(thymeleafItemCategoriesPojo.getName());
		itemCategoriesPojo.setUrl(thymeleafItemCategoriesPojo.getName().replaceAll("[^\\p{Alpha}\\p{Digit}]+", "").toLowerCase());

		if (thymeleafItemCategoriesPojo.getSubItemCategoriesID() == null) {
			itemCategoriesPojo.setSubItemCategoriesID(0L);
		} else {
			itemCategoriesPojo.setSubItemCategoriesID(thymeleafItemCategoriesPojo.getSubItemCategoriesID());
		}

		itemCategoriesRepository.save(itemCategoriesPojo);

		if (banner.equals("withBanner")) {
			ItemsPojo itemsPojo = new ItemsPojo();
			ImgStoragePojo imgStoragePojo = utilsService.uploadItemCategoriesOrItems("ItemCategories", uploadedFiles, selectedGroup,
					itemCategoriesPojo, itemsPojo);

			if (imageSize.equals("imageSizeWidth")) {
				imgStoragePojo.setDisplaySize("width: " + imageSizeWidthPixel + "px");
				utilsService.saveThisImgStoragePojo(imgStoragePojo);
			}
		}

		return itemCategoriesPojo;
	}

}
