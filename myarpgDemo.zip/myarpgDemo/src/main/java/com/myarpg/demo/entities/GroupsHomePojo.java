package com.myarpg.demo.entities;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class GroupsHomePojo {

	@GeneratedValue
	@Id
	private Long groupsHomeID;

	@ManyToOne(cascade = CascadeType.ALL)
	private GroupsHomePojo groupsHomePojo;
	private Long groupID;
	private Integer position;
	private String url;
	private String fragment;
	private String type;
	
	@Column(length = 1000)
	private String optionalContainer;

	public GroupsHomePojo() {
	}

	public Long getGroupsHomeID() {
		return groupsHomeID;
	}

	public void setGroupsHomeID(Long groupsHomeID) {
		this.groupsHomeID = groupsHomeID;
	}

	public GroupsHomePojo getGroupsHomePojo() {
		return groupsHomePojo;
	}

	public void setGroupsHomePojo(GroupsHomePojo groupsHomePojo) {
		this.groupsHomePojo = groupsHomePojo;
	}

	public Long getGroupID() {
		return groupID;
	}

	public void setGroupID(Long groupID) {
		this.groupID = groupID;
	}

	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getFragment() {
		return fragment;
	}

	public void setFragment(String fragment) {
		this.fragment = fragment;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getOptionalContainer() {
		return optionalContainer;
	}

	public void setOptionalContainer(String optionalContainer) {
		this.optionalContainer = optionalContainer;
	}
	

}
